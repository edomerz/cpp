/*------------------------------------------------------------------
  $Id: Sockets.C,v 1.3 1998/03/21 00:45:36 omalley Exp $

  Description

  Copyright (c) 1997-98 The Regents of the University of Michigan.
  ------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <signal.h>
#include <errno.h>
#include <sys/time.h>
#include <assert.h>

#include <sys/errno.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>

#include "Sockets.H"



/********************************************************************
  Read a line from a descriptor.  Read the line one byte at a time,
  looking for the newline or NUL terminator.  We store the newline
  or NUL in the buffer, then follow it with a null.
  
  We return the number of characters read up to, but not including,
  the null.

  Based on code from "UNIX Network Programming" W. Richard Stevens
  1990, p. 280.
********************************************************************/
int
ReadAPIString(int fd, char *ptr, int maxlen)
{
  int	n, rc;
  char	c;

  if (fd < 0)
  {
    (void)printf("Socket:ReadAPIString: negative value passed in argument 1\n");
    return 0;
  }

  if (ptr == NULL)
  {
    (void)printf("Socket:ReadAPIString: NULL pointer passed in argument 2\n");
    return 0;
  }

  if ( (maxlen <= 0) || (maxlen > MAX_API_STRING_LEN) )
  {
    (void)printf("Socket:ReadAPIString: out-of-range value passed argument 3\n");
    return 0;
  }
  
  for (n=1; n<maxlen; n++)
  {
    if ( (rc = read(fd, &c, 1)) == 1)
    {
      *ptr++ = c;

      if ( (c == '\n') || (c == '\0') || (c == 0) )
        break;
    }
    else if (rc == 0)
    {
      if (n == 1)
      {
        (void)printf("Socket:ReadAPIString:  EOF, no data read\n");
        return(0);
      }
      else
      {
        (void)printf("Socket:ReadAPIString: EOF, some data was read\n");
        break;		 
      }
      
    }
    else
    {
      (void)printf("Socket:ReadAPIString: error\n");
      return(-1);
    }
    
  }
  
  *ptr = '\0';
  return(n);
}


/********************************************************************
  Write a string to a descriptor.
  
  We return the number of characters written up to, but not including,
  the null.

  Based on code from "UNIX Network Programming" W. Richard Stevens
  1990, pp. 279-280.
********************************************************************/
int
WriteAPIString(int fd, char *ptr, int nBytes)
{
  int	nleft, nwritten;
  
  if (fd < 0)
  {
    (void)printf("Socket:WriteAPIString: negative value passed in argument 1\n");
    return 0;
  }

  if (ptr == NULL)
  {
    (void)printf("Socket:WriteAPIString: NULL pointer passed in argument 2\n");
    return 0;
  }

  if ( (nBytes <= 0) || (nBytes > MAX_API_STRING_LEN) )
  {
    (void)printf("Socket:WriteAPIString: out-of-range value passed argument 3\n");
    return 0;
  }
   
  nleft = nBytes + 1;
  while (nleft > 0)
  {
    nwritten = write(fd, ptr, nleft);
    if (nwritten <= 0)
      return(nwritten);		/* error */
    
    nleft -= nwritten;
    ptr   += nwritten;
  }
  return(nBytes - nleft);
}


/********************************************************************
  Setup a connection to the server.
  Returns 0 if connected, < 0 if not. 
********************************************************************/
int
SetupConnection(const char *servname, int port, int& sd)
{
  int err, enable;
  struct sockaddr_in saddr;
  struct hostent *ptrh;
  
  if (servname == NULL)
  {
    (void)printf("Socket:SetupConnection: NULL pointer passed in argument 1\n");
    return -2;
  }

  if (port < 0)
  {
    (void)printf("Socket:SetupConnection: out-of-range value passed argument 2\n");
    return -2;
  }

  // create a TCP socket
  sd = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP);
  if (sd < 0)
  {
    (void)printf("Socket:SetupConnection: error creating the TCP socket\n");    
    return -2;
  }
  
  // initialize socket address 
  memset((char *) &saddr, 0, sizeof(struct sockaddr_in));
  saddr.sin_family = AF_INET;
  saddr.sin_port = htons((u_short) port);
  
  // set socket to KEEPALIVE
  enable = 1;
  err = setsockopt(sd, SOL_SOCKET, SO_KEEPALIVE, (char *) &enable, sizeof(int));
  if (err)
  {
    (void)printf("Socket:SetupConnection: error setting socket option\n");    
    return -2;
  }
  
  // convert "servname" to IP address
  ptrh = gethostbyname(servname);
  if (ptrh == NULL)
  {
    (void)printf("Socket:SetupConnection: error getting host by name\n");    
    return -2;
  }
  
  memcpy(&saddr.sin_addr, ptrh->h_addr, ptrh->h_length);
  
  // connect to the specific server
  err = connect(sd, (struct sockaddr *) &saddr, sizeof(saddr));
  if (err < 0)
  {
    (void)printf("Socket:SetupConnection: error connecting to server\n");    
    return -2;
  }
  
  return 0;
}

// local variables:
// mode: c++
// compile-command: "make Sockets.o"
// end:






