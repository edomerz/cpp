#ifndef __CIRC_BUF_H__
#define __CIRC_BUF_H__

#include <stdio.h>
#include <pthread.h> /* pthread_mutex_init/lock/unlock */
#include <semaphore.h>

#endif /* __CIRC_BUF_H__ */

#ifndef __CONSUMER_PRODUCER_H__
#define __CONSUMER_PRODUCER_H__

struct circ_buf
{
	size_t capacity;				/* total elements */
	size_t size; 					/* number of written elements */
	size_t read_index;
	size_t write_index;
	size_t circular_buffer[1];
};

typedef struct args 
{
	circ_buf_t *circ_buf;
	pthread_mutex_t *circbuf_mutex;
	sem_t *free_space_semaphore;
	sem_t *occupied_space_semaphore;
} args_t;


void *CircBuffWriter(void *args);
void *CircBuffReader(void *args);

#endif /* __CONSUMER_PRODUCER_H__ */
