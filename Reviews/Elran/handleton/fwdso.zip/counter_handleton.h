/****************************************
*
*	counter_handleton Project Header file:	counter_handleton.h
*	05-04-2016
*	
*	Production : Elran Sarusi
*	Reviewed by :
*
****************************************/

#ifndef __COUNTER_HANDLETON_H__
#define __COUNTER_HANDLETON_H__


#include<iostream>

class counter
{
public:
	void Inc() ;
	void Dec();
	void PrintCounter();
private:
	int m_counter;
};



#endif  /******** these are function declarations for __COUNTER_HANDLETON_H__ ************/
