/*------------------------------------------------------------------
  $Id: Utils.C,v 1.2 1998/03/19 20:42:59 omalley Exp $

  Description
  These are some low-level C functions that handle strings.

  Copyright (c) 1997-98 The Regents of the University of Michigan.
  ------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <ctype.h>
#include <assert.h>
#include <time.h>

#include "Utils.H"


/********************************************************************
  Strip double quotes from a string and trim white space.
  Returns 0 on no error, 1 on an error.
********************************************************************/
int
StripQuotes(char *str)
{
  char *p = str;

  if (str == NULL)
    return 1;

  while(*p != NULL)
  {
    if (*p == '"')
      *p = ' ';
    p++;
  }
  
  return TrimSpace(str);
}


/********************************************************************
  Convert a string to lower case.
  Returns 0 on no error, 1 on an error.
********************************************************************/
int
StrToLower(char *s)
{
  char *p;

  if (s == NULL)
    return 1;

  p = s;
  while(*p != NULL)
  {
    if (isupper(*p))
      *p = (char)tolower(*p);
    p++;
  }
  return 0;
}


/********************************************************************
  Remove whitespace from the end of the string.
  Returns 0 on no error, 1 on an error.
********************************************************************/
int
TrimTrailingSpace(char *str)
{
  int  i;

  if (str == NULL)
    return 1;
  
  i = (int)strlen(str) - 1;
  if (i < 0)                    // in the case of an empty string
    return 0;
  
  while (isspace(str[i]))
    i--;

  str[i+1] = '\0';
  return 0;
}


/********************************************************************
  Remove whitespace from the beginning of the string.
  Returns 0 on no error, 1 on an error.
********************************************************************/
int
TrimLeadingSpace(char *s)
{
  char *p;

  if (s == NULL)
    return 1;

  p = s;
  while (isspace(*p))
    p++;

  strcpy(s, p);
  return 0;
}


/********************************************************************
  Remove whitespace from the beginning and end of the string.
  Returns 0 on no error, 1 on an error.
********************************************************************/
int
TrimSpace(char *str)
{
  if (str == NULL)
    return 1;

 if (TrimLeadingSpace(str) != 0)
   return 1;
 
 if (TrimTrailingSpace(str) != 0)
   return 1;
 
 return 0;
}


/********************************************************************
  Convert a string to upper case.
  Returns 0 on no error, 1 on an error.
********************************************************************/
int
StrToUpper(char *s)
{
  char *p;

  if (s == NULL)
    return 1;

  p = s;
  while(*p != NULL)
  {
    if (islower(*p))
      *p = (char)toupper(*p);
    p++;
  }
  return 0;
}

// local variables:
// mode: c++
// compile-command: "make Utils.o"
// end:
