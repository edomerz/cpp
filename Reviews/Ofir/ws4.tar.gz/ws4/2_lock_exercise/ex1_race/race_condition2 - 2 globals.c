#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>

#define ARRAY_SIZE 10000

size_t global_array[ARRAY_SIZE] = {0};
size_t global_value = 1;
size_t writer_is_busy = 0;
size_t reader_is_busy = 0;

void *Writer(void *sleep_time_duration)
{
	size_t i = 0;
	
	while(1)
	{
		if (!reader_is_busy)
		{
			writer_is_busy = 1;
			
			printf("started writing, sir (reader_is_busy == %lu, writer_is_busy == %lu)\n", reader_is_busy, writer_is_busy);
			for (i = 0; i < ARRAY_SIZE ; ++i)
			{
				global_array[i] = global_value;
				/* usleep(*(size_t *)sleep_time_duration); */
				
				if (!(i % 1000))
				{
					printf("written arr[%lu] = %lu\n", i, global_array[i]);	
				}	
				usleep(*(size_t *)sleep_time_duration);
			}
			
			if (i == ARRAY_SIZE)
			{
				printf("written arr[%lu] = %lu\n", i-1, global_array[i-1]);
			}
			
			++global_value;
			printf("finished writing, sir\n");
			writer_is_busy = 0;
		}	
	}
	
	return (NULL);
}

void *Reader(void *sleep_time_duration)
{
	size_t i = 0;
	size_t first_cell_value;
	
	while(1)
	{
		if (!writer_is_busy)
		{
			reader_is_busy = 1;
			first_cell_value = global_array[0];
		
			printf("\t\t\tstarted reading, sir\n");

		
			for (i = 0; i < ARRAY_SIZE ; ++i)
			{
				usleep(*(size_t *)sleep_time_duration);
				
				if (first_cell_value != global_array[i])
				{
					printf("\t\t\toh no! the is_busy flag hadn't really blocked!\n");
					printf("\t\t\tfirst_cell_value: %lu\n", first_cell_value);
					printf("\t\t\tglobal_array[%lu]: %lu\n", i, global_array[i]);
					usleep(*(size_t *)sleep_time_duration);
					reader_is_busy = 0;
					break;	
				}
				
				
				if (!(i % 1000))
				{
					
					printf("\t\t\tread arr[%lu] = %lu\n",  i, global_array[i]);
				
				}
				
				
			}
			if (i == ARRAY_SIZE)
			{
				printf("\t\t\tread arr[%lu] = %lu\n", i-1, global_array[i-1]);
			}
		
			usleep(*(size_t *)sleep_time_duration);
			printf("\t\t\tfinished reading, sir\n");
			reader_is_busy = 0;
		}	
	}
	
	return (NULL);
}

int main (int argc, char **argv)
{
	size_t i;
	size_t sleep_time_duration = 0;
	
	/* this will hold the thread id */
	pthread_t writer_thread_id;
	pthread_t reader_thread_id;
	
	if (argc < 2)
	{
		fprintf (stderr, "you forgot entering a -d option and arguments to it\n");
		return;
	}
	
	if ((sleep_time_duration = getopt(argc, argv, "d:")) != -1)
	{
		switch (sleep_time_duration)
		{
			case 'd':
				sleep_time_duration = atoi(optarg);
				break;
				
			/* If getopt() does not recognize an option character, it prints an 
				error message to stderr, stores the character in optopt, and 
				returns '?'	*/
			case '?':
				if (optopt == 'd')
				{
					fprintf (stderr, "Option -%c requires an argument.\n", optopt);
				}
				else if (isprint(optopt))
				{
					fprintf (stderr, "Unknown option `-%c'.\n", optopt);
				}   
				else
				{
					fprintf (stderr, "Unknown option character `\\x%x'.\n", optopt);
				} 
       			return 1;
       			
			default:
       	 		abort ();
		}
	}
	
	
	/* THREADS */
	pthread_create(&writer_thread_id, NULL, &Writer, &sleep_time_duration);
	pthread_create(&reader_thread_id, NULL, &Reader, &sleep_time_duration);

	pthread_join(writer_thread_id, NULL);
	pthread_join(reader_thread_id, NULL);
	
	
	return (0);	
}
