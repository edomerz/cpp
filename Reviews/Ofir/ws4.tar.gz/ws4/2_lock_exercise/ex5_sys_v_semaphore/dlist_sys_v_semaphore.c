#include <sys/types.h>	/* semget(), semctl(), semop()  (somehow it works without this include) */
#include <sys/ipc.h>	/* semget(), semctl(), semop() (somehow it works without this include) */
#include <sys/sem.h>	/* semget(), semctl(), semop() */
#include <pthread.h> 	/* pthread_mutex_/init()/destroy()/lock/unlock */
#include <unistd.h>		/* usleep() */
#include <errno.h> 		/* errno, perror() */
#include "dlist.h"

/* #define KEY IPC_PRIVATE */

/* for compiling usleep with our usual flags */
/* #define _BSD_SOURCE */ 
/* #define _SVID_SOURCE */

#define SLEEP_DURATION 100

size_t global_counter = 0;

pthread_mutex_t dlist_mutex;

void MutexDestroy(void);

union semun 
{
    int val;
    struct semid_ds *buf;
    ushort *array;
};

typedef struct args 
{
	int semid;
	dlist_t *dlist;
} args_t;

/* this is how the struct sembuf - used inside the wait & the post functions - 
	looks like: 
	struct sembuf 	
	{
		ushort sem_num;
		short sem_op;
		short sem_flg;
	};
*/

/* Initialize a mutex & a semaphore with a value of 0 (meaning: the dlist has 0 nodes). */
/* key from ftok(), num_of_semaphores with value '1' means one semaphore */
int InitSemaphore(key_t key, int num_of_semaphores)  
{
    /* mendatory declaration of union semun (semaphore_union), to be used for 
    	assiging its .val member with the desired initial value of the semaphore */
    union semun semun_instance;
     
    /* IPC_EXCL: When used with IPC_CREAT, fail if semaphore set already exists. */
    /* 666 are rw-rw-rw- permissions (for the user to r&w the semaphores set) */
    int semid = semget(key, num_of_semaphores, IPC_CREAT | IPC_EXCL | 0666);
    
	/* if semid >=0, the semget returned a non-zero semid value, and it means that a new 
		semaphores set was created */
    /* if the semaphore's id that complies with the passed key is already exists,
    	and semflg specified both IPC_CREAT and IPC_EXCL, semget returns an error, 
    	namely: it updates errno with EEXIST value */ 
    if (errno == EEXIST) 
    { 
		/* get the id */
        semid = semget(key, num_of_semaphores, 0);
         
        /* if semid is negative, that's an error, check errno */
        if (semid < 0) 
        {
        	perror("semid error");
			exit(1);
        }   	  	
	}
	
	/* used for SETVAL only */
    semun_instance.val = 0;
    
	/* SETVAL means: Set the value of the specified semaphore to the value 
		in the val member of the passed-in union semun. */
	semctl(semid, 0, SETVAL, semun_instance);
	
	/* to get the semaphore value */
    /* printf("semval: %d\n", ); */
    
    /* initializing the mutex */
    pthread_mutex_init(&dlist_mutex, NULL);
    
    /* executes only at normal process termination, so it won't be executed... */
    atexit(MutexDestroy);
    
    return semid;
}

void MutexDestroy(void)
{
	pthread_mutex_destroy(&dlist_mutex);
}

/* Wait on a semaphore (will be used only by Reader function):
	Block until the semaphore value is positive (= the list is NOT empty), 
	then atomically decrement it by 1. */
int SemaphoreWait(int semid)
{
	struct sembuf operations;
	
	/* Use the first (and only) semaphore. */
	operations.sem_num = 0;
	
	/* Decrement by 1. */
	/* if the semaphore's value is non-1, Reader will wait */
	operations.sem_op = -1;
	
	/* Permit undo'ing. */
	operations.sem_flg = SEM_UNDO;
	
	/* this is the actual setting of the semaphore's value. */
	/* NOTE: you can use semctl(semid, 0, GETVAL) to see the semaphore's value */
	return semop(semid, &operations, 1);
}

/* Post to the semaphore (will be used only by Writer function): 
	atomically increment its value by 1 (= a new node was pushed into the dlist) */
int SemaphorePost(int semid)
{
	struct sembuf operations;
	
	/* Use the first (and only) semaphore. */
	operations.sem_num = 0;
	
	/* Increment by 1; (Beej calls it 'Release' resources, and in our context it
		is a bit confusing...we can say it means: enable a reading from the list 
		by n'enabling' nodes, by creating nodes). */
    /* The value of sem_op is added to the semaphore's value. */
	operations.sem_op = 1;
	
	/* Permit undo'ing. */
	operations.sem_flg = SEM_UNDO;
	
	return semop(semid, &operations, 1);
}

/*  DListFrontWriter pushes an element to the front of the  dlist and prints 
	the updated size of the list resulted from the writing operation */
void *DListFrontWriter(void *args)
{	
	while (1)
	{	
		/* locking the mutex while checking for a non-error value */
		if (pthread_mutex_lock(&dlist_mutex))
		{
			perror("writer pthread_mutex_lock() error");
			exit(1);
		}
		
		/* pushing the element. we use the global_counter as the element's data */
		DListPushFront(((args_t *)args)->dlist, (void *)global_counter);
		
		/* updating the counter */
		++global_counter;
		
		/* varifying the size equals the counting */
		printf("dlist updated size, after writing: %lu (expected: %lu)\n", 
				global_counter, DListSize(((args_t *)args)->dlist));
						
		/* Post to the semaphore: increment its value by 1 */
		SemaphorePost(((args_t *)args)->semid);
		
		/* unlocking the mutex */
		if (pthread_mutex_unlock(&dlist_mutex))
		{
			perror("writer pthread_mutex_unlock() error");
			exit(1);
		}
		
		/* a short sleep to be able to see what's printing */
		usleep(SLEEP_DURATION);
	}
	
	/* unused */

	return NULL;	
}

/*  DListFrontReader pops the first element of the list and prints the updated 
	size of the list resulted from the reading operation */
void *DListFrontReader(void *args)
{
	while (1)
	{	
		/* waiting on the semaphore if its value is 0. otherwise, atomically 
			decrements its value by 1 and move on. */
		SemaphoreWait(((args_t *)args)->semid);
		
		/* locking the mutex while checking for a non-error value */
		if (pthread_mutex_lock(&dlist_mutex))
		{
			perror("writer pthread_mutex_lock() error");
			exit(1);
		}
		
		/* popping the lis't first element. */
		DListPopFront(((args_t *)args)->dlist);
		
		/* updating the counter */
		--global_counter;
			
		/* varifying the size equals the counting */
		printf("\t\t\tdlist updated size, after reading: %lu (expected: %lu)\n", 
				global_counter, DListSize(((args_t *)args)->dlist));
				
		/* unlocking the mutex */
		if (pthread_mutex_unlock(&dlist_mutex))
		{
			perror("writer pthread_mutex_unlock() error");
			exit(1);
		}
		
		/* a short sleep to be able to see what's printing */	
		usleep(SLEEP_DURATION);	
	}
	
	/* unused */
	return NULL;	
}
