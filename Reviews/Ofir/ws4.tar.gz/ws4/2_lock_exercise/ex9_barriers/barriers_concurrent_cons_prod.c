#define _BSD_SOURCE
#define _GNU_SOURCE		
#include <unistd.h>		/* usleep() */
#include <errno.h> 		/* errno, perror() */
#include "circ_buf.h"
#include "barriers_concurrent_cons_prod.h"

#define SLEEP_DURATION_READER 0
#define SLEEP_DURATION_WRITER 0

int global_counter = 0;

/*  Writes an element into the next available-to-write index inside the circ_buf */
void *CircBuffWriter(void *args)
{	
	size_t i = 0;
	
	while (1)
	{	
		printf("started writing\n");
		
		for (i = 0; i < ((args_t *)args)->capacity; ++i)
		{
			/* writing the element. we use the global_counter as the element's data */
			CircBufWrite(((args_t *)args)->circ_buf, &global_counter);
			
			if (!(i % 2))
			{
				printf("written: %d, into circbuf[%lu]\n", global_counter, i); 
			}
		}

		/* updating the counter */
		++global_counter;
		
		printf("finished writing\n\n");
		
		/* a short sleep to be able to see what's printing */
		usleep(SLEEP_DURATION_WRITER);
						
		/* after writing, the writer needs to wait on the done_writing barrier.
			 once the writer thread calls the wait function, the wait function 
			 decrements the done_writing barrier's (which is a struct) counter member 
			 by 1. once its value becomes 0, the writer thread moves on to the next
			 instruction - the call to the wait function with the done_reading barrier.
			 note: the value of the done_writing counter becomes 0 once all the reader
			 threads called the wait function with this same done_writing barrier. */
		pthread_barrier_wait(&((args_t *)args)->done_writing);
		
		/* this empty zone is called a "waiting room" */
		
		/* after "exiting" the done_writing barrier, the writer thread needs to 
			wait on the done_reading barrier, because we want it to start writing
			only once all the readers threads finished a single-cycle of consuming 
			the circ_buf.
			 once the writer thread calls the wait function, the wait function 
			 decrements the done_reading barrier's counter member 
			 by 1. once its value becomes 0, the writer thread moves on to the next
			 instruction - which is the beggining of the loop. 
			 note: the value of the done_reading counter becomes 0 once all the reader
			 threads finish their consuming operation and called the wait function 
			 with this same done_reading barrier. */
		pthread_barrier_wait(&((args_t *)args)->done_reading);
		
		/* NOTE: everything would have worked the same with a single barrier */
	}
	
	/* unused */
	return NULL;	
}

/*  Reads the next available-to-read element from the circ_buf */
void *CircBuffReader(void *args)
{
	size_t i = 0;
	int returned;
	
	while (1)
	{	
		/* see comments above */
		pthread_barrier_wait(&((args_t *)args)->done_writing);
		
		printf("\t\t\tstarted reading (my pthread_id: %lu)\n", (size_t)pthread_self());
		
		for (i = 0; i < ((args_t *)args)->capacity; ++i)
		{
			returned = CircBufRead(((args_t *)args)->circ_buf);
		
			if (!(i % 2))
			{
				printf("\t\t\tread: %d, from circbuf[%lu]\n", returned, i); 
			}
		}		
					
		printf("\t\t\tfinished reading (my pthread_id: %lu)\n\n", (size_t)pthread_self());	
		
		/* see comments above */	
		pthread_barrier_wait(&((args_t *)args)->done_reading);
			
		/* a short sleep to be able to see what's printing */	
		usleep(SLEEP_DURATION_READER);	
	}
	
	/* unused */
	return NULL;	
}
