#include <pthread.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/time.h>

typedef struct encapuslating
{
	size_t i;
	size_t range;

} capsule;

capsule capsule1 = {0, 5}; 
capsule capsule2 = {0, 5}; 
capsule capsule3 = {0, 5};

size_t global_array[10000] = {0};
size_t global_array2[10000] = {0};

pthread_t thread_ids1[10000] = {0};
pthread_t thread_ids2[2000] = {0};


void *PrintX(void *my_capsule)
{
	global_array[((capsule *)my_capsule)->i] = ((capsule *)my_capsule)->i;
	
	return (NULL);
}


void *PrintX2(void *my_capsule)
{
	size_t i2 = ((capsule *)my_capsule)->i;
	size_t range = ((capsule *)my_capsule)->range;
	size_t j = 0;
	
	for (j = 0; ((i2 * range + j) % range) + 1 < range; ++j)
	{
		global_array2[i2 * range + j] = i2 * range + j;
	}
	global_array2[i2 * range + j] = i2 * range + j;

	return (NULL);
}


int main()
{
	size_t i;
	double time[3] = {0};
	struct timeval begin, end;
	
	/* this will hold the thread id */
	pthread_t thread_id;
	
	/* THREADS LOOP */
	gettimeofday (&begin, NULL);
	for (i = 0; i < 10000; ++i)
	{
		capsule1.i = i;
		pthread_create(&thread_id, NULL, &PrintX, &capsule1);
		thread_ids1[i] = thread_id;
	}
	gettimeofday (&end, NULL);
	time[0] = ((end.tv_sec - begin.tv_sec)*1E6 + end.tv_usec - begin.tv_usec)/1E6;
	
	for (i = 0; i < 10000; ++i)
	{
		pthread_join(thread_ids1[i], NULL);
	}
	
	for (i = 0; i < 10000; ++i)
	{
		printf("global_array[%lu]: %lu\n", i, global_array[i]);
	}

	/* FASTER THREADS LOOP */
	gettimeofday (&begin, NULL);
	for (i = 0; i < 2000; ++i)
	{
		capsule2.i = i;
		pthread_create(&thread_id, NULL, &PrintX2, &capsule2);
		thread_ids2[i] = thread_id;
	}
	gettimeofday (&end, NULL);
	time[1] = ((end.tv_sec - begin.tv_sec)*1E6 + end.tv_usec - begin.tv_usec)/1E6;
	
	for (i = 0; i < 2000; ++i)
	{
		pthread_join(thread_ids2[i], NULL);
	}
	
	for (i = 0; i < 10000; ++i)
	{
		printf("global_array2[%lu]: %lu\n", i, global_array2[i]);
	}

	/* SERIAL LOOP */
	gettimeofday (&begin, NULL);
	#pragma omp parallel for
	for (i = 0; i < 10000; ++i)
	{
		capsule3.i = i;
		PrintX(&capsule3);
	}
	gettimeofday (&end, NULL);
	time[2] = ((end.tv_sec - begin.tv_sec)*1E6 + end.tv_usec - begin.tv_usec)/1E6;
	
	for (i = 0; i < 10000; ++i)
	{
		printf("global_array[%lu]: %lu\n", i, global_array[i]);
	}
	
	printf("threads loop time: %f\n", time[0]);
	printf("faster threads loop time: %f\n", time[1]);
	printf("serial loop time: %f\n", time[2]);
	
	
	
	return (0);	
}
