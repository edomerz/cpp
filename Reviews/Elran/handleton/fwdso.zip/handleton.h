/****************************************
*
*	handleton Project Header file:	handleton.h
*	05-05-2016
*	
*	Production : Elran Sarusi
*	Reviewed by :
*
****************************************/

#ifndef __HANDLETON_H__
#define __HANDLETON_H__


#include<string>
#include<iostream>
#include<cstdlib>
#include<boost/noncopyable.hpp>
#include<pthread.h>
#include<stdio.h>
#include<sched.h>

namespace ilrd {


template<typename T>
class Handleton
{
public:
	Handleton();
	static  T*& GetInstance();
	T*& operator ->();
private:
	static int test_lock;
	static  T* m_instance;
	static void DestroyInstance();


};


template<typename T>
int Handleton<T>::test_lock = 0;

//init the static data member
template<typename T>
T* Handleton<T>::m_instance = 0;

template<typename T>
T*& Handleton<T>::operator->()
{
	return (GetInstance());
}


template<typename T>
Handleton<T>::Handleton()
{
}

#ifdef __INSTANCE_EN__
template<typename T>
 T*& Handleton<T>::GetInstance()
{
	T* temp = 0;

	if (!m_instance)
	{
		/*look for documentation on __sync func used here*/
		if (!__sync_val_compare_and_swap(&test_lock,0 , 1))
		{
			temp = new T;
			atexit(&DestroyInstance);
			if(temp)
			{
				 m_instance =  __sync_or_and_fetch (&m_instance, temp);
			}
		}
		/*we have an instance wait (yield cpu time) nand m_instance will be supp[lied*/
		while(!m_instance)
		{
			/*sleep - when u wake up thread has valid instance pointer to give*/
			sched_yield();
		}

	}
	return (m_instance);
}



template<typename T>
void Handleton<T>::DestroyInstance()
{
		delete GetInstance();
		GetInstance() = reinterpret_cast<T*>(0xdeadbeef);
}

#endif



} /* namespace ilrd */



#endif  /******** these are function declarations for __HANDLETON_H__ ************/
