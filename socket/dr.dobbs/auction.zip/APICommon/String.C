/*------------------------------------------------------------------
  $Id: String.C,v 1.2 1998/03/19 20:42:58 omalley Exp $

  Description

  Copyright (c) 1997-98 The Regents of the University of Michigan.
  ------------------------------------------------------------------*/
#include <assert.h>
#include <string.h>

#include "String.H"



/********************************************************************
  Default constructor.
********************************************************************/
String::String()
{
  mLen = 0;
  mStr = new char[1];
  mStr[0] = '\0';
}


/********************************************************************
  Default constructor.
********************************************************************/
String::String(const char *s)
{
  mLen = (int)strlen(s);
  mStr = new char[mLen+1];
  assert(mStr);

  strcpy(mStr, s);
}


/********************************************************************
  Default destructor.
********************************************************************/
String::~String()
{
  delete [] mStr;
}


/********************************************************************
  Provides indexing into a String.
********************************************************************/
char
String::operator[](int i)
{
  if ( (i < 0) || (i > mLen) )
  {}
  
  return mStr[i];
}


/********************************************************************
  String concat.
********************************************************************/
String&
String::operator+=(const String& str)
{ 
   mLen += str.mLen;
   char *p = mStr;
   mStr = new char[mLen + 1];
   assert(mStr);
   
   strcpy(mStr, p);
   strcat(mStr, str.mStr);
   delete [] p;
   return *this;
}


/********************************************************************
  String copy.
********************************************************************/
String&
String::operator=(const String& str)
{ 
  if (&str != this)
  {
    delete [] mStr;
    mLen = str.mLen;  
    mStr = new char[mLen+1];
    strcpy(mStr, str.mStr);
  }
  return *this;
}


/********************************************************************
  String concat.
********************************************************************/
String&
String::operator+=(const char *str)
{ 
   mLen += strlen(str);
   char *p = mStr;
   mStr = new char[mLen + 1];
   assert(mStr);
   
   strcpy(mStr, p);
   strcat(mStr, str);
   delete [] p;
   return *this;
}


/********************************************************************
  String copy.
********************************************************************/
String&
String::operator=(const char *str)
{ 
  delete [] mStr;
  
  mLen = (int)strlen(str);
  mStr = new char[mLen+1];
  assert(mStr);

  strcpy(mStr, str);
  return *this;
}


/********************************************************************
  Returns the length of the String.
********************************************************************/
int
String::Length()
{
  return mLen;
}

// local variables:
// mode: c++
// compile-command: "make String.o"
// end:
