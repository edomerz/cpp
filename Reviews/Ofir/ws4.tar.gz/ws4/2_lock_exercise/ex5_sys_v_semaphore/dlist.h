/********************************************************
*											 			*
*	The Following functions implement a Doubly  		*
*	linked list (DList) data structure.					*
*														*
*	Ofir Deutscher, 04.01.2016							*
*											 			*
********************************************************/

#ifndef __DLIST_H__
#define __DLIST_H__

#include <stdio.h>
#include <stdlib.h>
#include <sys/ipc.h>

typedef struct dlist dlist_t;
typedef struct dlist_node *dlist_iter_t;

typedef int(*is_match_func)(const void *data, const void *seek);
typedef int(*action_func)(void *data, void *param);

/* Creates a new list and returns a pointer to it. */
dlist_t *DListCreate(void);

/* Destroys a list. */
void DListDestroy(dlist_t *dlist);

/* Counts the number of elements inside the list and returns it. */
size_t DListSize(const dlist_t *dlist);

/* Checks if the list is empty. If true returns 1, else - returns 0. */
int DListIsEmpty(const dlist_t *dlist);

/* Returns an iterator to the first/last element of a list. */
dlist_iter_t DListBegin(const dlist_t *dlist);
dlist_iter_t DListEnd(const dlist_t *dlist);

/* Returns an iterator to the succeeding/preceding element of item. */
dlist_iter_t DListNext(const dlist_iter_t item);
dlist_iter_t DListPrev(const dlist_iter_t item);

/* Checks if two iterators points to them same element.
If true returns 1, else - returns 0. */
int DListIsSameIter(const dlist_iter_t iter1, const dlist_iter_t iter2);

/* Returns the data of item. */
void *DListGetData(dlist_iter_t item);

/* Inserts a new element before  where, assign it with data and returns to it. */
dlist_iter_t DListInsertBefore(dlist_t *dlist, dlist_iter_t where, void *data);

/* Removes the element. */
dlist_iter_t DListRemove(dlist_iter_t element);

/* Insert a new element to the beginning/end of the list, assign it with
new data, and return it. */
dlist_iter_t DListPushFront(dlist_t *dlist, void *data);
dlist_iter_t DListPushBack(dlist_t *dlist, void *data);

/*  Removes the first/last element of the list. */
void *DListPopFront(dlist_t *dlist);
void *DListPopBack(dlist_t *dlist);

/*  Pushes the element pointed by 'data' to the front of the 
	dlist and prints the updated size of the list resulted from the writing operation */
void *DListFrontWriter(void *args);
void *DListFrontReader(void *args);

int InitSemaphore(key_t key, int num_of_semaphores);

#endif /* __DLIST_H__ */

