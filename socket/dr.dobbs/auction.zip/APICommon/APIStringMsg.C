/*------------------------------------------------------------------
  $Id: APIStringMsg.C,v 1.3 1998/03/21 00:45:34 omalley Exp $

  Description

  Copyright (c) 1997-98 The Regents of the University of Michigan.
  ------------------------------------------------------------------*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h> 
#include <unistd.h>
#include <assert.h>

#include "String.H"
#include "APIStringMsg.H"



/*+******************************************************************
  Default constructor.
******************************************************************+*/
APIStringMsg::APIStringMsg()
{
}


/*+******************************************************************
  Constructor passed the operation type.
******************************************************************+*/
APIStringMsg::APIStringMsg(char *opType)
{
  mStatus = 0;
  if (opType == NULL)
  {
    mStatus = 1;
    return;  
  }
  
  AddOpType(opType);
}


/*+******************************************************************
  Destructor.
******************************************************************+*/
APIStringMsg::~APIStringMsg()
{  
}


/*+******************************************************************
  Add the operation type to the string.
******************************************************************+*/
void
APIStringMsg::AddOpType(char *opType)
{
  if (opType == NULL)
  {
    mStatus = 1;
    return;  
  }

  mReplyStr = opType;
  mReplyStr += "?";  
}



/*+******************************************************************
  Return the internal string as a char *.
******************************************************************+*/
APIStringMsg::operator char *() const
{
  return (char *)(const char *)mReplyStr;
}


/*+******************************************************************
  Add a term pair (label/value) as char* char* to the string.
******************************************************************+*/
void
APIStringMsg::AddTerm(char *keyword, const char *val)
{
  if ( (keyword == NULL) || (val == NULL) || (strlen(keyword) == 0) )
  {
    mStatus = 1;
    return;  
  }

  if (mReplyStr[mReplyStr.Length()-1] != '?')
    mReplyStr += "&";  

  mReplyStr += keyword;
  mReplyStr += "=";
  mReplyStr += "\"";

  if (strlen(val) != 0)
    mReplyStr += val;    
  
  mReplyStr += "\"";
}


/*+******************************************************************
  Add a term pair (label/value) as char * int to the string.
******************************************************************+*/
void
APIStringMsg::AddTerm(char *keyword, int val)
{
  if ( (keyword == NULL) || strlen(keyword) == 0)
  {
    mStatus = 1;
    return;  
  }

  if (mReplyStr[mReplyStr.Length()-1] != '?')
    mReplyStr += "&";  

  // This should be changed once the apm is done.
  char s[256];
  sprintf(s, "%d", val);
  
  mReplyStr += keyword;
  mReplyStr += "=";
  mReplyStr += s;
}


/*+******************************************************************
  Add a term pair (label/value) as char * long to the string.
******************************************************************+*/
void
APIStringMsg::AddTerm(char *keyword, long val)
{
  if ( (keyword == NULL) || strlen(keyword) == 0)
  {
    mStatus = 1;
    return;  
  }

  if (mReplyStr[mReplyStr.Length()-1] != '?')
    mReplyStr += "&";  

  // This should be changed once the apm is done.
  char s[256];
  sprintf(s, "%ld", val);
  
  mReplyStr += keyword;
  mReplyStr += "=";
  mReplyStr += s;
}


/*+******************************************************************
  Add a term pair (label/value) as char * double to the string.
******************************************************************+*/
void
APIStringMsg::AddTerm(char *keyword, double val)
{
  if ( (keyword == NULL) || strlen(keyword) == 0)
  {
    mStatus = 1;
    return;  
  }

  if (mReplyStr[mReplyStr.Length()-1] != '?')
    mReplyStr += "&";  

  char s[256];
  sprintf(s, "%f", val);
  
  mReplyStr += keyword;
  mReplyStr += "=";
  mReplyStr += s;
}


// local variables:
// mode: c++
// compile-command: "make APIStringMsg.o"
// end:
