#define _GNU_SOURCE
#include "circ_buf.h"
#include "barriers_concurrent_cons_prod.h"

#define WRITER_THREADS 1
#define READER_THREADS 4

int main()
{
	int i = 0;
	size_t capacity = 10;
	
	pthread_t writer_threads_id_array[WRITER_THREADS] = {0}; 
	pthread_t reader_threads_id_array[READER_THREADS] = {0}; 
	
	args_t args_instance;
	
	/* initializing the barriers */
	if(pthread_barrier_init(&args_instance.done_writing, NULL, WRITER_THREADS + READER_THREADS))
	{
		perror("pthread_mutex_init() error");
		exit(1);
	}
	if(pthread_barrier_init(&args_instance.done_reading, NULL, WRITER_THREADS + READER_THREADS))
	{
		perror("pthread_mutex_init() error");
		exit(1);
	}
	
	/* creating circular buffer */
	args_instance.circ_buf = CircBufCreate(capacity);
	
	args_instance.capacity = capacity;
	
	/* Testing DListWriter & DListReader, that use mutexes */
	/**********************************************************************/
	
	for (i = 0 ; i < WRITER_THREADS; ++i)
	{
		if (pthread_create(&writer_threads_id_array[i], NULL, CircBuffWriter, &args_instance))
		{
			perror("pthread_create() error");                                           
    		exit(1);
		}
	}
	for (i = 0 ; i < READER_THREADS; ++i)
	{	
		if (pthread_create(&reader_threads_id_array[i], NULL, CircBuffReader, &args_instance))
		{
			perror("pthread_create() error");                                           
    		exit(1);
		}
	}
	
	for (i = 0 ; i < WRITER_THREADS; ++i)
	{
		if (pthread_join(writer_threads_id_array[i], NULL))
		{
			perror("pthread_join() error");                                       
    		exit(2);
		}
	}
	for (i = 0 ; i < WRITER_THREADS; ++i)
	{
		if (pthread_join(reader_threads_id_array[i], NULL))
		{
			perror("pthread_join() error");                                       
    		exit(2);
		}
	}
			

	/* WON'T BE EXECUTED SINCE WE DONT HAVE A NORMAL TERMINATION HERE (WE TERMINATE
		WITH CTRL+C)  */
	/* ***********************************************************************/
	/* destroying the two lists. */
	CircBufDestroy(args_instance.circ_buf);
	
	/* destroying the barriers. */
	if(pthread_barrier_destroy(&args_instance.done_writing))
	{
		perror("pthread_mutex_destroy() error");
		exit(1);
	}
	if(pthread_barrier_destroy(&args_instance.done_reading))
	{
		perror("pthread_mutex_destroy() error");
		exit(1);
	}
	

	return (0);
}

