#include <pthread.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/time.h>

size_t global_array[10000] = {0};
size_t global_array2[10000] = {0};
pthread_t thread_ids[10000] = {0};
pthread_t thread_ids2[2000] = {0};

/* a simple function that prints 100 x's */
void *PrintX(void *i)
{
	global_array[(size_t)i] = (size_t)i;
	
	return (NULL);
}

void *PrintX2(void *i)
{
	size_t i2 = (size_t)i;
	size_t j = 0;
	size_t range = 5;
	
	for (j = 0; ((i2 * range + j) % range) + 1 < range; ++j)
	{
		global_array2[i2 * range + j] = i2 * range + j;
	}
	global_array2[i2 * range + j] = i2 * range + j;

	
	return (NULL);
}

int main()
{
	size_t i;
	/*size_t range = 5;*/
	double time[3] = {0};
	struct timeval begin, end;
	
	/* this will hold the thread id */
	pthread_t thread_id;
	
	/* THREADS LOOP */
	gettimeofday (&begin, NULL);
	for (i = 0; i < 10000; ++i)
	{
		pthread_create(&thread_id, NULL, &PrintX, (void *)i);
		thread_ids[i] = thread_id;
	}
	gettimeofday (&end, NULL);
	time[0] = ((end.tv_sec - begin.tv_sec)*1E6 + end.tv_usec - begin.tv_usec)/1E6;
	
	for (i = 0; i < 10000; ++i)
	{
		pthread_join(thread_ids[i], NULL);
	}
	
	/* FASTER THREADS LOOP */
	gettimeofday (&begin, NULL);
	for (i = 0; i < 2000; ++i)
	{
		pthread_create(&thread_id, NULL, &PrintX2, (void *)i);
		thread_ids2[i] = thread_id;
	}
	gettimeofday (&end, NULL);
	time[1] = ((end.tv_sec - begin.tv_sec)*1E6 + end.tv_usec - begin.tv_usec)/1E6;
	
	for (i = 0; i < 2000; ++i)
	{
		pthread_join(thread_ids2[i], NULL);
	}

	/* SERIAL LOOP */
	gettimeofday (&begin, NULL);
	
	/*#pragma omp parallel for*/
	
	for (i = 0; i < 10000; ++i)
	{
		PrintX((void *)i);
	}
	gettimeofday (&end, NULL);
	time[2] = ((end.tv_sec - begin.tv_sec)*1E6 + end.tv_usec - begin.tv_usec)/1E6;
	
	printf("threads loop time: %f\n", time[0]);
	printf("faster threads loop time: %f\n", time[1]);
	printf("serial loop time: %f\n", time[2]);
	
	
	
	return (0);	
}
