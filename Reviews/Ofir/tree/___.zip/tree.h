#ifndef __TREE_H__				
#define __TREE_H__				
				
#include <vector>				
				
namespace ilrd				
{				
	class Component				
	{				
	public:				
		Component(const std::string& name_);
		std::string GetName() const;
		virtual ~Component();			
		virtual void Display(int level, int flag = 1) const = 0;
	private:				
		std::string m_name;			
	};				
				
	class Directory : public Component				
	{				
	public:				
		Directory(const std::string& name_);			
		~Directory();			
				
		void Display(int level, int flag = 1) const;
		void Add(Component *inst_);
		
		std::vector<Component *>& GetVec();
		
	private:				
		std::vector<Component *> v;	
		friend Component* FindPath(Component* repo_, const std::string& path_); 		
	};				
				
	class File : public Component				
	{				
	public:				
		File(const std::string& name_);			
		~File();			
				
		void Display(int level, int flag = 1) const;
	};				
				
	Component* CreateRepository(const std::string& path_);				
	Component* FindPath(Component* repo_, const std::string& path_);						
}				
				
				
				
#endif /* tree.h  */				
