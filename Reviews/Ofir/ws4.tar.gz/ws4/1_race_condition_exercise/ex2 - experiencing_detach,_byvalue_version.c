size_t global_array[50000] = {0};


void *PrintX(void *i)
{
	global_array[(size_t)i] = (size_t)i;
	
	return (NULL);
}


int main()
{
	size_t i;
	

	pthread_t thread_id;
	
	for (i = 0; i < 50000; ++i)
	{
		pthread_create(&thread_id, NULL, &PrintX, (void *)i);
		pthread_detach(thread_id);
	}
	
	for (i = 0; i < 50000; ++i)
	{
		printf("global_array[%lu]: %lu\n", i, global_array[i]);
	}
	
	return (0);	
}
