//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by critest.rc
//
#define IDD_MAINDLG                     101
#define IDD_STREAMDLG                   101
#define IDD_BLOCKDLG                    102
#define IDC_TEXT                        1000
#define IDC_CONNECT                     1001
#define IDC_SEND                        1002
#define IDC_MODLIST                     1003

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
