#include <stdlib.h>
#include <pthread.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include "dlist.h"

int main()
{
	pthread_t writer_thread_id;
	pthread_t reader_thread_id;
	
	typedef struct args 
	{
		pthread_mutex_t *dlist_mutex;
		sem_t *dlist_semaphore;
		dlist_t *dlist;
	} args_t;
	args_t args_instance;
	
	pthread_mutex_t dlist_mutex;
	sem_t dlist_semaphore;
	
	if(pthread_mutex_init(&dlist_mutex, NULL))
	{
		perror("pthread_mutex_init() error");
		exit(1);
	}
	args_instance.dlist_mutex = &dlist_mutex;
	
	if(sem_init(&dlist_semaphore, 0, 0))
	{
		perror("sem_init() error");
		exit(1);
	}
	args_instance.dlist_semaphore = &dlist_semaphore;
	
	/* creating list */
	args_instance.dlist = DListCreate();
	

	/* Testing DListWriter & DListReader, that use mutexes */
	/**********************************************************************/
	
	if (pthread_create(&writer_thread_id, NULL, DListFrontWriter, &args_instance))
	{
		perror("pthread_create() error");                                           
    	exit(1);
	}
	if (pthread_create(&reader_thread_id, NULL, DListFrontReader, &args_instance))
	{
		perror("pthread_create() error");                                           
    	exit(1);
	}
	
	if (pthread_join(writer_thread_id, NULL))
	{
		perror("pthread_join() error");                                       
    	exit(2); 
	}
	if(pthread_join(reader_thread_id, NULL))
	{
		perror("pthread_join() error");                                       
    	exit(2); 
	}
	
	
	/* WON'T BE EXECUTED SINCE WE DONT HAVE A NORMAL TERMINATION HERE (WE TERMINATE
		WITH CTRL+C)  */
	/* ***********************************************************************/
	/* destroying the two lists. */
	DListDestroy(args_instance.dlist);
	
	/* destroying the semaphore. */
	if(sem_destroy(&dlist_semaphore));
	{
		perror("sem_destroy() error");
		exit(1);
	}
	
	/* destroying the mutex. */
	if(pthread_mutex_destroy(&dlist_mutex))
	{
		perror("pthread_mutex_destroy() error");
		exit(1);
	}
	
	
	return (0);
}



