/*------------------------------------------------------------------
  $Id: example.C,v 1.1.1.1 1998/03/14 20:14:03 omalley Exp $

  Description
  A simple example program that connects to the server,
  sends strings to the server and echos the server response.
  
  Copyright (c) 1997-98 The Regents of the University of Michigan.
  ------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <signal.h>
#include <time.h>

#include <sys/types.h>
#include <sys/errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <assert.h>

#include "String.H"
#include "Sockets.H"
#include "Utils.H"
#include "APIStringData.H"
#include "APIStringMsg.H"

int
main(int argc, char *argv[])
{
  int   port = 50001;
  char *servname = (char *)"auction.eecs.umich.edu";
  int  err = 0, sd = 0, nBytes = 0;
  FILE *fp;
  
  if ((err = SetupConnection(servname, port, sd)) < 0)
  {
    (void)printf("error on SetupConnection()\n");
    exit(EXIT_FAILURE); 
  }

  (void)printf("connected to address: %s\n", servname);
  (void)printf("port:                 %d\n", port);

  char s[MAX_API_STRING_LEN + 1];
  char recvbuf[MAX_API_STRING_LEN + 1];

  if (argc == 2)
  {
    fp = fopen(argv[1], "r");
    if (fp == NULL)
    {
      printf("error opening input file\n");
      return 0;
    }

    int cnt = 0;
    while (!feof(fp))
    {
      s[0] = 0;
      recvbuf[0] = 0;
      
      (void)fgets(s, MAX_API_STRING_LEN, fp);
      if (strlen(s) <= 0)
        break;

      if (s[0] == '#')
        continue;
      
      (void)printf("-- (%d)\n%s", cnt++, s);
      nBytes = WriteAPIString(sd, (char *)s, strlen(s));
      if (nBytes == 0)
      {        
        (void)fprintf(stderr, "example: WriteAPIString returned 0 bytes, calling exit(0)\n");
        exit(EXIT_FAILURE); 
      }
      
      nBytes = ReadAPIString(sd, recvbuf, MAX_API_STRING_LEN);
      if (nBytes == 0)
      { 
        (void)fprintf(stderr, "example: ReadAPIString returned 0 bytes, calling exit(0)\n");
        exit(EXIT_FAILURE); 
      }
      
      (void)printf("%s\n", recvbuf);
    }
    fclose(fp);
  }
  else
  {
    (void)printf("type API commands to send to the server\n");
    while (1)
    {
      s[0] = 0;
      recvbuf[0] = 0;
      
      (void)printf(": ");
      (void)fgets(s, MAX_API_STRING_LEN, stdin);

      nBytes = WriteAPIString(sd, (char *)s, strlen(s));
      if (nBytes == 0)
      {        
        (void)printf("example: WriteAPIString returned 0 bytes, calling _exit(0)\n");
        exit(EXIT_FAILURE); 
      }
      
      nBytes = ReadAPIString(sd, recvbuf, MAX_API_STRING_LEN);
      if (nBytes == 0)
      { 
        (void)printf("example: ReadAPIString returned 0 bytes, calling _exit(0)\n");
        exit(EXIT_FAILURE); 
      }
      
      (void)printf("%s\n", recvbuf);
    }
  }
  
  return 0;
}
