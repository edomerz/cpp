#ifndef __DUMMY_H__
#define __DUMMY_H__



#include	"handleton.h"
#include	"counter_handleton.h"

extern "C" void DoAdd();

#endif /*              __DUMMY_H__       */
