#include "circ_buf.h"
#include "concurrent_consumer_producer.h"

#define WRITER_THREADS 4
#define READER_THREADS 4

int main()
{
	int i = 0;
	size_t capacity = 10;
	
	pthread_t writer_threads_id_array[WRITER_THREADS] = {0}; 
	pthread_t reader_threads_id_array[READER_THREADS] = {0}; 
	
	args_t args_instance;
	
	/* declaring the mutexes */
	pthread_mutex_t writer_mutex;
	pthread_mutex_t reader_mutex;
	
	/* declaring the semaphores */
	sem_t free_space_sem;
	sem_t occupied_space_sem;
	
	/* initializing the mutexes */

	if(pthread_mutex_init(&args_instance.writer_mutex, NULL))
	{
		perror("pthread_mutex_init() error");
		exit(1);
	}
	if(pthread_mutex_init(&args_instance.reader_mutex, NULL))
	{
		perror("pthread_mutex_init() error");
		exit(1);
	}
	
	/* initializing the semaphores */
	if(sem_init(&args_instance.free_space_semaphore, 0, capacity))
	{
		perror("sem_init() error");
		exit(1);
	}
	if(sem_init(&args_instance.occupied_space_semaphore, 0, 0))
	{
		perror("sem_init() error");
		exit(1);
	}
	
	/* creating circular buffer */
	args_instance.circ_buf = CircBufCreate(capacity);
	
	/* Testing DListWriter & DListReader, that use mutexes */
	/**********************************************************************/
	
	for (i = 0 ; i < WRITER_THREADS; ++i)
	{
		if (pthread_create(&writer_threads_id_array[i], NULL, CircBuffWriter, &args_instance))
		{
			perror("pthread_create() error");                                           
    		exit(1);
		}
		
		if (pthread_create(&reader_threads_id_array[i], NULL, CircBuffReader, &args_instance))
		{
			perror("pthread_create() error");                                           
    		exit(1);
		}
	}
	
	for (i = 0 ; i < WRITER_THREADS; ++i)
	{
		if (pthread_join(writer_threads_id_array[i], NULL))
		{
			perror("pthread_join() error");                                       
    		exit(2);
		}
		
		if (pthread_join(reader_threads_id_array[i], NULL))
		{
			perror("pthread_join() error");                                       
    		exit(2);
		}	
	}

	/* WON'T BE EXECUTED SINCE WE DONT HAVE A NORMAL TERMINATION HERE (WE TERMINATE
		WITH CTRL+C)  */
	/* ***********************************************************************/
	/* destroying the two lists. */
	CircBufDestroy(args_instance.circ_buf);
	
	/* destroying the mutexes. */
	if(pthread_mutex_destroy(&writer_mutex))
	{
		perror("pthread_mutex_destroy() error");
		exit(1);
	}
	if(pthread_mutex_destroy(&reader_mutex))
	{
		perror("pthread_mutex_destroy() error");
		exit(1);
	}
	
	/* destroying the semaphores. */
	if(sem_destroy(&free_space_sem));
	{
		perror("sem_destroy() error");
		exit(1);
	}
	if(sem_destroy(&occupied_space_sem));
	{
		perror("sem_destroy() error");
		exit(1);
	}

	return (0);
}

