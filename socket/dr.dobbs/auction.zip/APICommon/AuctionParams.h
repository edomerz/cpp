/* *********************************
   This file contains definitiions for
   AuctionBot wide constants and enumerated
   types.

   Suggested naming conventions:
   Constants    kSampleConstant
   Variables    sampleVariable
   Functions    SampleFunction()
   Types        Sample_Type

   Version Date     Who   Comments
   1.00    6/20/96  PW    Created
   1.01    7/15/96  PW    Changed enums to typed enums.
   1.02	   7/16/96  wew   Added kUndefinedPrice
   1.03	   8/10/96  wew   Added enum Bid_Invalid_Reason	
   1.04	   8/16/96  PW    Removed Bid_Size and made it a BidRule.	
   1.05    5/1/97   PW    Changed all enumerations to be explicit
*/

#ifndef _AUCTION_PARAMS_
#define _AUCTION_PARAMS_

//  Ten years (in seconds) is the default length
//  of an auction if it is specified as terminating
//  when all goods are bought or sold.
const kTenYears = 315360000;

// For RW collection classes.
const defaultMaxPoints = 100;
const defaultMaxBids = 100;

const int kBidStringLength = 2900;

/*
Auction type constants.   

These must correspond to the auction type files in the auctionTypes
directory.
*/
enum Auction_Type{
  kTestChronologicalMatch = -4,
  kTestMthPrice = -3,
  kTestMPlusFirstPrice = -2,
  kTest = -1,
  kMPlusFirstPrice = 1,
  kMthPrice = 2,
  kVickrey = 3,
  kChronologicalMatch = 4,
  kContinuousDouble = 5
};

enum Auction_Status{
  kInitializing = 0,
  kIntermediateClear = 1,
  kFinalClear = 2,
  kClosed = 3
};

enum Good_Units{
  kContinuousGoods = 0,
  kDiscreteGoods = 1
};

enum Num_Buyers{
  kOneBuyer = 1,
  kManyBuyers = 2
};

enum Num_Sellers{
  kOneSeller = 1,
  kManySellers = 2
};

enum Membership{
  kPublicAuction = 0,
  kSemiPrivateAuction = 1
};

// The number of notification options
#define kNumNotifications 8


// Disclosure is not a mutually exclusive set.
// It would allow the following characters:
#define kDiscloseOwner         'o'
#define kDiscloseWinner        'w'
#define kDiscloseTransactions  't'
#define kDiscloseBids          'b'
#define kDiscloseQuoteMode     'n'
#define kDiscloseClearMode     'N'


// Notifications are used in both bids and
// auctions.  The notifies selected in a bid
// must be a subset of those allowed by the
// auction.  The three that are always present
// don't need to be explicityly specified.
// #define kNotifyBidRejection     'r'   // This should always be present
// #define kNotifyMyTransactions   't'   // This should always be present
// #define kNotifyFinalClear       'c'   // This should always be present

#define kNotifyBidValidation    'v'   // Used by bids, not auctions
#define kNotifyBidExpiration    'e'   // Used by bids, not auctions
#define kNotifyAllTransactions  'T'
#define kNotifyPriceQuotes      'q'
#define kNotifyClearingPrice    'p'



// This is used for price Quotes.

enum Price_Policy{
  kPolicyClearPrice = 0,
  kPolicyBidPrice = 1,
  kPolicyAskPrice = 2,
  kPolicyBidAsk = 3,
  kPolicyDeltaBidPrice = 4,
  kPolicyDeltaAskPrice = 5
};


// The following enumerations handles price quote modes
// and both kinds of clearing modes.  They are allowed
// according to the following:
//         Mode = Price_Quote   Int_Clear   Final_Clear
//    None            X           X
//    Immediate       X           X            X
//    Periodic        X           X
//    Schedule        X           X
//    OnDemand        X
//    FixedTime                                X
//    Inactivity                  X            X
//    Random                                   X
//    ZeroBuyers                               X
//    ZeroSellers                              X

enum Auction_Mode{
  kModeNone = 0,
  kModeImmediate = 1,
  kModePeriodic = 2,
  kModeSchedule = 3,
  kModeOnDemand = 4,
  kModeFixedTime = 5,
  kModeInactivity = 6,
  kModeRandom = 7,
  kModeZeroBuyers = 8,
  kModeZeroSellers = 9
};


// Bid Rules:  
//    The following define restrictions
//    on bid types and activities.  These are parameters
//    of auctions. There is room for 8 flags.
//    Note that the rules <1, s, S, m, M> are mutually
//    exclusive and define the bidding question to be asked.
//    Also the set <i,d,D> are mutually exclusive, defining the
//    dominance checking type.
//    (5/14/97 changed kBidRuleAllowIndivisible from 'd' to 'I')

#define kBidRuleIncrementPriceOrQuantity   'i' 
#define kBidRuleDecrementPriceOrQuantity   'd'
#define kBidRuleBuyUpSellDown              'D'
#define kBidRuleBeatQuote                  'b'

#define kBidRuleAllowIndivisible      'I'   // can be enforced by UI
#define kBidRuleSingleUnitOnly        '1'   // can be enforced by UI
#define kBidRuleSinglePointBuyOrSell  's'   
#define kBidRuleSinglePointBuyAndSell 'S'
#define kBidRuleManyPointsBuyOrSell   'm'   // doesn't seem useful restriction over kBidRuleManyPointsBuyAndSell
#define kBidRuleManyPointsBuyAndSell  'M'



enum Bid_Mode{
  kExpireWhenFilled = 0,
  kExpireWhenPartlyFilled = 1,
  kExpireAtTime = 2,
  kExpireWithNextClear = 3
};

enum Bid_Status{
  kBidUnprocessed = 0,
  kBidRejected = 1,
  kBidValid = 2,
  kBidWithdrawn = 3,
  kBidTransacted = 4,
  kBidReplaced = 5,
  kBidExpired = 6,
  kBidPartiallyTransacted = 7,
  kBidWithdrawRequested = 8
};


enum Notify_Method{
  kNotifyByHTML = -1,		// Do not notify.  User must check
				// account on AuctionBot.
  kNotifyByEmail = 0,
  kNotifyByHTTP = 1,
  kNotifyBySocket = 2
};


enum Tie_Breaking_Rule{
  kBreakTieByFIFO = 0,
  kBreakTieBySize = 1,
  kBreakTieByBestFit = 2,
  kBreakTieByDistribution = 3,
  kBreakTieArbitrarily = 4
};

#endif

// local variables:
// mode: c++
// end:
