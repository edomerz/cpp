#include <pthread.h>	/* pcreate(), pjoin() */
#include <sys/types.h>	/* ftok, key_t */
#include <sys/ipc.h> 	/* ftok (though somehow it works without this include) */
#include <sys/sem.h> 	/* semctl */
#include "dlist.h"

union semun 
{
    int val;
    struct semid_ds *buf;
    ushort *array;
};

int main()
{
	pthread_t writer_thread_id;
	pthread_t reader_thread_id;
	key_t key;
	struct args 
	{
		int semid;
		dlist_t *dlist;
	} args_instance;
	
	union semun semun_arg;
	
	/* creating list */
	args_instance.dlist = DListCreate();
	
	/* checking the two lists has been created and that they're empty */
	if (args_instance.dlist)
	{
		printf("the first doubly linked list has come into life!\n");
	}
	printf("as for now, the list contains %lu elements.\n", DListSize(args_instance.dlist));
	printf("\n");

	/* Testing DListWriter & DListReader, that use mutexes */
	/**********************************************************************/
	
	/* produce a unique key based on the path (first argument) and the int value
		(second argumnt. the 's' is just a convenience for semaphore). 
		if you want a different key, change one of them */
	key = ftok("dlist.c", 'S');	
	args_instance.semid = InitSemaphore(key, 1);

	if (pthread_create(&writer_thread_id, NULL, DListFrontWriter, &args_instance))
	{
		perror("pthread_create() error");                                           
    	exit(1);
	}
	if (pthread_create(&reader_thread_id, NULL, DListFrontReader, &args_instance))
	{
		perror("pthread_create() error");                                           
    	exit(1);
	}
	
	if (pthread_join(writer_thread_id, NULL))
	{
		perror("pthread_join() error");                                       
    	exit(2); 
	}
	if(pthread_join(reader_thread_id, NULL))
	{
		perror("pthread_join() error");                                       
    	exit(2); 
	}
	
	
	/* WON'T BE EXECUTED SINCE WE DONT HAVE A NORMAL TERMINATION HERE (WE TERMINATE
		WITH CTRL+C)  */
	/* ***********************************************************************/
	/* destroying the two lists. */
	DListDestroy(args_instance.dlist);
	
	/* destroying the semaphore set. */
	semctl(args_instance.semid, 0, IPC_RMID, semun_arg);
	
	return (0);
}



