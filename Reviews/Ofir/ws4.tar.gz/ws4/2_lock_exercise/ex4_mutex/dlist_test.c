#include <stdlib.h>
#include <pthread.h>
#include "dlist.h"

int main()
{
	pthread_t writer_thread_id;
	pthread_t reader_thread_id;
	
	/* creating two lists */
	dlist_t *dlist = DListCreate();
	
	/* checking the two lists has been created and that they're empty */
	if (dlist)
	{
		printf("the first doubly linked list has come into life!\n");
	}
	printf("as for now, the list contains %lu elements.\n", DListSize(dlist));
	printf("\n");

	/* Testing DListWriter & DListReader, that use mutexes */
	/**********************************************************************/
	
	if (pthread_create(&writer_thread_id, NULL, DListFrontWriter, dlist))
	{
		perror("pthread_create() error");                                           
    	exit(1);
	}
	if (pthread_create(&reader_thread_id, NULL, DListFrontReader, dlist))
	{
		perror("pthread_create() error");                                           
    	exit(1);
	}
	
	if (pthread_join(writer_thread_id, NULL))
	{
		perror("pthread_join() error");                                       
    	exit(2); 
	}
	if(pthread_join(reader_thread_id, NULL))
	{
		perror("pthread_join() error");                                       
    	exit(2); 
	}
	
	/* destroying the two lists. */
	DListDestroy(dlist);
	
	return (0);
}



