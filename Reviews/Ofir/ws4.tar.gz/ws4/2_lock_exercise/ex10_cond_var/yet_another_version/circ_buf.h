/********************************************************
*											 			*
*	The Following functions implements a circular  		*
*	buffer data structure.								*
*	The circular buffer has a fixed capacity, defined 	*
*	by the user.										*
*	Writing into the buffer is possible only if there's	*
*	free place to write into.							*
*	Reading an element means "consuming" it, so that 	*
*	after an element is read - its space is free to 	*
*	write into.											*
*														*
*	Ofir Deutscher, 29.12.2015							*
*   Data Structures, ciruclar buffer (exercise 5) 		*
*											 			*
********************************************************/

#ifndef __CIRC_BUF_H__
#define __CIRC_BUF_H__

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>


typedef struct circ_buf circ_buf_t;  
 
/* Creates a circular buffer with "capacity" bytes, and returns a pointer to it */
circ_buf_t *CircBufCreate(size_t capacity);

/* Destroys a circular buffer */
void CircBufDestroy(circ_buf_t *circ_buf_instance);

/* Returns the free space (in bytes) left to write on in the buffer */
size_t CircBufFreeSpace(const circ_buf_t *circ_buf_instance);

/* Returns the total capacity (in bytes) of the buffer */
size_t CircBufCapacity(const circ_buf_t *circ_buf_instance);

/* Reads "n_bytes" from the buffer, storing them at the location given by 
	dest. It returns the number of bytes read.  */
int CircBufRead(circ_buf_t *circ_buf_instance);

/* Writes "n_bytes" to the buffer, obtaining them from the location given by src. 
	It returns the number of bytes written. */
void CircBufWrite(circ_buf_t *circ_buf_instance, const int *data);

/* Returns 1 if the buffer is empty, else 0 */
int CircBufIsEmpty(const circ_buf_t *circ_buf_instance);

#endif /* __CIRC_BUF_H__ */
