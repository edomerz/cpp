/********************************************
*
*	shared_ptr Project definition file:	shared_ptr.cpp
*	04-13-2016
*	
*	Production : Elran Sarusi
*	Reviewed by :
*
*********************************************/



#include"shared_ptr.h"

  





