/*------------------------------------------------------------------
  $Id: APIStringData.C,v 1.2 1998/03/19 20:42:54 omalley Exp $

  Description

  Copyright (c) 1997-98 The Regents of the University of Michigan.
  ------------------------------------------------------------------*/

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <time.h>

#include "APIStringData.H"
#include "Utils.H"


/********************************************************************
  Default constructor. Passed a string that is decoded and added 
  to the symbol table.
********************************************************************/
APIStringData::APIStringData(char *p)
{
  if (p == NULL)
  {
    (void)printf("APIStringData:APIStringData: NULL value passed in argument 1\n");
    return;
  }

  ReadFromString(p);
}


/********************************************************************
  Default destructor.
********************************************************************/
APIStringData::~APIStringData()
{
}


/********************************************************************
 This routine reads from a char buffer until a designated
 stopping character is encountered.  It fills the string "buf" as 
 it goes.
********************************************************************/
int 
APIStringData::ReadBlock(char *f, char *buf, char stop)
{
  int charcount = 0;
  int ch;
  
  if (f == NULL)
  {
    (void)printf("APIStringData:ReadBlock: NULL value passed in argument 1\n");
    return 0;
  }
  if (buf == NULL)
  {
    (void)printf("APIStringData:ReadBlock: NULL value passed in argument 2\n");
    return 0;
  }

  while(*f)
  {
    ch = *f++;
    if ((ch == 0) || (ch==stop) || (ch == EOF))
      break;
    if (charcount < MAX_LEN-1)
    {
      *buf = (char)ch;
      buf++;
      charcount++;
    }
  }
  *buf = '\0';
  return charcount;
}


/********************************************************************
 This routine reads the string into the symbol table.
********************************************************************/
void
APIStringData::ReadFromString(char *str)
{
  char buf[256];
  char *valueP, *p;

  if (str == NULL)
  {
    (void)printf("APIStringData:ReadFromString: NULL value passed in argument 1\n");
    return;
  }

  p = str;
  int nBytes = ReadBlock(p, buf, '?');
  if (nBytes == 0)
  {
    return;
  }

  Add("optype", (const char *)buf);

  // Get the rest of the values
  p += nBytes+1;  
  while( (nBytes = ReadBlock(p, buf, '&')) > 0)
  {
    valueP = SplitValue(buf);
    if (valueP)
    {
      UnescapeURL(buf);
      UnescapeURL(valueP);
      StripQuotes(buf);
      StripQuotes(valueP);      
      Add(buf, valueP);
    }
   p += nBytes+1;   
  }
}



/********************************************************************
  This routine converts a hex encoded number into a character.
********************************************************************/
char 
APIStringData::x2c(char *cP)
{
  char digit;

  if (cP == NULL)
  {
    (void)printf("APIStringData:x2c: NULL value passed in argument 1\n");
    return ' ';
  }

  digit = 0;
  digit += (*cP >= 'A' ? ((*cP & 0xdf) - 'A')+10 : (*cP - '0'));
  digit *= 16; cP++;
  digit += (*cP >= 'A' ? ((*cP & 0xdf) - 'A')+10 : (*cP - '0'));
  
  return (digit);
}



/********************************************************************
  This routine unencodes special characters from a URL
  The mappings seem to be:
     "%xx"  -> a char
     "+"    -> space
  This routine changes things in place. i.e. it overwrites the string
  as it goes.  It only works because the decoding always shortens the
  string, so the pointer x (write) always stays behind the point y
  (read).
********************************************************************/
void 
APIStringData::UnescapeURL(char *url)
{
  int x,y;
  x = 0; y = 0;
  
  if (url == NULL)
  {
    (void)printf("APIStringData:UnescapeURL: NULL value passed in argument 1\n");
    return;
  }

  while (url[y])
    {
      if (url[y] == '%') 
	{
	  url[x] = x2c(&(url[y+1]));
	  y+=2;
	} else if (url[y] == '+') {
	  url[x] = ' ';
	} else {
	  url[x] = url[y];
	}
      x++; y++;
    }
  url[x] = '\0';
}


		

/********************************************************************
  This routine splits up a key=value pair by replacing the "=" with
  NULL and returning a pointer to the second string.  The first string
  is effectively truncated to the key.
********************************************************************/
char *
APIStringData::SplitValue (char *buf)
{
  char *valueP;
  char *cP;

  if (buf == NULL)
  {
    (void)printf("APIStringData:SplitValue: NULL value passed in argument 1\n");
    return NULL;
  }

  valueP = NULL;
  cP = buf;
  while (*cP != '\0')
    {
      if (*cP == '=')
	{
	  *cP = '\0';
	  valueP = cP+1;
	  break;
	}
      cP++;
    }
  return valueP;
}



/********************************************************************
  Looks at the status value and returns -1 if server did not return
  a status label or the value of the status label. 
********************************************************************/
int
APIStringData::StatusValue()
{
  char *p = Find("status");
  int   rc = 0;

  if (p == NULL)
    return -1;
  
  // Check if the string contans all digits
  char *q = p;
  while(*q)
  {
    if (!isdigit(*q))
      return -1;
    q++;
  }

  rc = atoi(p);
  
  return rc;
}


// local variables:
// mode: c++
// compile-command: "make APIStringData.o"
// end:
