#include <assert.h>
#include <stdlib.h>
#include "dlist.h"

/* struct dlist_node represents the structre of a single node inside the 
	doubly linked list */
typedef struct dlist_node
{
	void *data;
	struct dlist_node *next;
	struct dlist_node *prev;
} dlist_node_t; /* its typedef in the head file is dlist_iter_t */

/* struct dlist represents the structre of the doubly linked list as a whole.
	the head & tail are "dummy nodes" and their data field won't be used. */
struct dlist
{
	dlist_node_t head;
	dlist_node_t tail;
}; /* its typedef in the head file is dlist_t */

/* Creates a new list and returns a pointer to it. */
dlist_t *DListCreate(void)
{
	dlist_t *new_dlist = (dlist_t *)malloc(sizeof(dlist_t));
	if (!new_dlist)
	{
		return NULL;
	}

	/* taking care of the next & prev pointers of the dummy head node */
	new_dlist->head.prev = NULL;
	new_dlist->head.next = &(new_dlist->tail);

	/* taking care of the next & prev pointers of the dummy tail node */
	new_dlist->tail.next = NULL;
	new_dlist->tail.prev = &(new_dlist->head);

	return (new_dlist);
}

/* Creats a single node */
dlist_iter_t DListCreateNode(dlist_iter_t prev_t, dlist_iter_t next_t, void *data_t)
{
	dlist_iter_t new_node = (dlist_iter_t)malloc(sizeof(dlist_node_t));
	if (!new_node)
	{
		return NULL;
	}

	/* intializing the node's pointers */
	new_node->data = data_t;
	new_node->prev = prev_t;
	new_node->next = next_t;

	/* stiching the node to its prev & next nodes */
	next_t->prev = new_node;
	prev_t->next = new_node;
	
	return (new_node);
}

/* Destroys a list. */
void DListDestroy(dlist_t *dlist)
{
	dlist_iter_t temp = NULL;
	
	assert(dlist);
	
	/* If the list contains only the dummy nodes, we only need to free dlist. */
	if (dlist->head.next == &(dlist->tail))  
	{
		free(dlist);
		return;
	}
	
	temp = dlist->head.next;

	while (temp->next)
	{
		temp = temp->next;
		free(temp->prev);
	}

	free(dlist);
}

/* void DListDestroy2(dlist_t *dlist)
{
	dlist_iter_t current = DListBegin(dlist), end = DListEnd(dlist);
	while (!DListIsSameIter(current, end))
	{
		current = DListRemove(current);
	}
	
	free(dlist);
} */

/* Counts the number of elements inside the list and returns it. */
size_t DListSize(const dlist_t *dlist)
{
	size_t counter = 0;
	dlist_iter_t temp = dlist->head.next;

	while (temp->next)
	{
		++counter;
		temp = temp->next;
	}

	return (counter);
}

/* Checks if the list is empty. If true returns 1, else - returns 0. */
int DListIsEmpty(const dlist_t *dlist)
{
	return (DListSize(dlist) == 0);
}

/* Returns an iterator to the first element of a list. */
dlist_iter_t DListBegin(const dlist_t *dlist)
{
	return (dlist->head.next);
}

/* Returns an iterator to the last element of a list. */
dlist_iter_t DListEnd(const dlist_t *dlist)
{
	return (dlist->tail.prev->next); /* another option:
										return ((dlist_iter_t) (&dlist->tail)) */
}

/* Returns an iterator to the succeeding element of item. */
dlist_iter_t DListNext(const dlist_iter_t item)
{
	return (item->next);
}

/* Returns an iterator to the preceding element of item. */
dlist_iter_t DListPrev(const dlist_iter_t item)
{
	return (item->prev);
}

/* Returns the data of item. */
void *DListGetData(dlist_iter_t item)
{
	return (item->data);
}

/* Checks if two iterators points to them same element.
If true returns 1, else - returns 0. */
int DListIsSameIter(const dlist_iter_t iter1, const dlist_iter_t iter2)
{
	return (iter1 == iter2);
}

/* Inserts a new element before where, assign it with data and returns to it. */
dlist_iter_t DListInsertBefore(dlist_t *dlist, dlist_iter_t where, void *data)
{	
	where->prev = DListCreateNode(where->prev, where, data);
	if (where->prev == NULL)
	{
		return (DListEnd(dlist));
	}

	return (where->prev);
}


/* Insert a new element to the beginning of the list, assign it with
new data, and return it. */
dlist_iter_t DListPushFront(dlist_t *dlist, void *data)
{
	dlist_iter_t new_start = DListInsertBefore(dlist, (dlist->head.next), data);

	return (new_start);
	
	/*return (DListInsertBefore((DListBegin(dlist)), data));*/
}

/* Insert a new element to the end of the list, assign it with
new data, and return it. */
dlist_iter_t DListPushBack(dlist_t *dlist, void *data)
{
	dlist_iter_t new_last = DListInsertBefore(dlist, &(dlist->tail), data);

	return (new_last);
}

/* Removes the element. */
dlist_iter_t DListRemove(dlist_iter_t element)
{
	dlist_iter_t returned_next = element->next;
	
	element->prev->next = element->next;
	if (element->next)
	{
		element->next->prev = element->prev;
	}
	free(element);

	return (returned_next);
}

/*  Removes the first element of the list. returns its data */
void *DListPopFront(dlist_t *dlist)
{
	void *returned_data = DListGetData(DListBegin(dlist));
	DListRemove(dlist->head.next);

	return (returned_data);
}

/*  Removes the last element of the list. returns its data*/
void *DListPopBack(dlist_t *dlist)
{
	void *returned_data = DListGetData(dlist->tail.prev);

	DListRemove(dlist->tail.prev);

	return (returned_data);
}

