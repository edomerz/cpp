#include "circ_buf.h"

int main()
{ 
	size_t capcity = 4;
	circ_buf_t *circ_buf_ptr = CircBufCreate(capcity); 

	int num1 = 65;
	int num2 = 66;
	int num3 = 67;
	int num4 = 68;  
	
	size_t i = 0;

	/**********************************************************************/
	/* examining the functions using ints and pointers to ints 			  */
	/**********************************************************************/
	
	/* before initializing */
	printf("FreeSpace of elements before writing: %lu\n", CircBufFreeSpace (circ_buf_ptr));

	/* Writing 3 elements (total bytes to write: 4+4+4) */
	printf("writing 3 int-type numbers to the circ_buffer.\n");
	
	if(CircBufFreeSpace(circ_buf_ptr))
	{
		CircBufWrite(circ_buf_ptr, &num1);
	}
	if(CircBufFreeSpace(circ_buf_ptr))
	{
		CircBufWrite(circ_buf_ptr, &num2);
	}
	if(CircBufFreeSpace(circ_buf_ptr))
	{
		CircBufWrite(circ_buf_ptr, &num3);
	}
	/* no free space now */
	
	printf("FreeSpace (in units of elements) after writing 3 elements: %lu elements\n", 
			CircBufFreeSpace (circ_buf_ptr));
	
	/* Reading the first 4 elements (= too much reading, since there are only 3 elements written */
	while (i < capcity)
	{
		if(CircBufFreeSpace(circ_buf_ptr) != capcity)
		{
			CircBufRead(circ_buf_ptr);
		}
		++i;
	}
	
	printf("FreeSpace (in units of elements) after reading 4 elements (= too much reading): %lu elements\n", CircBufFreeSpace (circ_buf_ptr));
	
	/* Writing 5 elements to the free space (= too much writing) */
	if(CircBufFreeSpace(circ_buf_ptr))
	{
		CircBufWrite(circ_buf_ptr, &num4); /* no free space now */
	}
	if(CircBufFreeSpace(circ_buf_ptr))
	{
		CircBufWrite(circ_buf_ptr, &num3);
	}
	if(CircBufFreeSpace(circ_buf_ptr))
	{
		CircBufWrite(circ_buf_ptr, &num2);
	}
	if(CircBufFreeSpace(circ_buf_ptr))
	{
		CircBufWrite(circ_buf_ptr, &num1);
	}
	if(CircBufFreeSpace(circ_buf_ptr))
	{
		CircBufWrite(circ_buf_ptr, &num4);
	}
	
	printf("FreeSpace (in units of elements) after writing another 5 elements (= too much writing): %lu elements\n", CircBufFreeSpace (circ_buf_ptr));
	
	printf("\n");
	
	if(CircBufFreeSpace(circ_buf_ptr) != capcity)
	{
		CircBufRead(circ_buf_ptr);
	}
	printf("FreeSpace (in units of elements) after reading 1 elements: %lu elements\n", 
			CircBufFreeSpace (circ_buf_ptr));
	if(CircBufFreeSpace(circ_buf_ptr))
	{
		CircBufWrite(circ_buf_ptr, &num4);
	}
	printf("FreeSpace (in units of elements) after writing 1 elements: %lu elements\n", 
			CircBufFreeSpace (circ_buf_ptr));
	
	CircBufDestroy(circ_buf_ptr);
	
	return (0);


}
