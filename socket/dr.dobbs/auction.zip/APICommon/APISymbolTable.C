/*------------------------------------------------------------------
  $Id: APISymbolTable.C,v 1.3 1998/03/21 00:45:35 omalley Exp $

  Description

  Copyright (c) 1997-98 The Regents of the University of Michigan.
  ------------------------------------------------------------------*/
#include <string.h>
#include <assert.h>
#include <stdio.h>

#include "APISymbolTable.H"


/********************************************************************
  Default constructor.
********************************************************************/
APISymbolTableEnt::APISymbolTableEnt()
  : labelS(0), valueS(0)
{
}


/********************************************************************
  Default destructor.
  ********************************************************************/
APISymbolTableEnt::~APISymbolTableEnt()
{
  if (labelS) 
    delete [] labelS;
  if (valueS) 
    delete [] valueS;
}


/********************************************************************
  Loads a value pair into the symbol table.
  ********************************************************************/
void
APISymbolTableEnt::Load(const char *l, const char *v)
{
  if ( (l == NULL) || (v == NULL) )
  {
    (void)printf("APISymbolTableEnt:Load: negative value passed in argument 1 or 2\n");
    return;
  }
  
  if (labelS) 
    delete [] labelS;
  if (valueS) 
    delete [] valueS;
  
  labelS = new char[strlen(l)+1];
  if (labelS == NULL)
  {
    (void)printf("APISymbolTableEnt:Load: error allocating memory\n");
    return;
  }
  
  valueS = new char[strlen(v)+1];
  if (valueS == NULL)
  {
    delete [] labelS;
    (void)printf("APISymbolTableEnt:Load: error allocating memory\n");
    return;
  }
  
  strcpy(labelS, l);
  strcpy(valueS, v);
}	


/********************************************************************
  Determines if the passed value is equal to the label.
  ********************************************************************/
int
APISymbolTableEnt::IsEqual (const char *l)
{
  if (labelS && l)
  {
    return (strcmp (l, labelS) == 0);
  } 
  else 
  {
    return 0;
  }
}


/********************************************************************
  Default constructor.
********************************************************************/
APISymbolTable::APISymbolTable()
  : mUsedCount (0)
{
}


/********************************************************************
  Default destructor. When the APISymbolTableEnts go out of scope, the
	destructors get called anyway, so nothing needs to be done here
********************************************************************/
APISymbolTable::~APISymbolTable()
{
}


/********************************************************************
  Adds a value pair (label/value) to the table. Returns -1 on
  failure.
********************************************************************/
int
APISymbolTable::Add(const char *labelS, const char *valueS)
{
  if ( (labelS == NULL) || (valueS == NULL) )
  {
    (void)printf("APISymbolTableEnt:Add: NULL value passed in argument 1 or 2\n");
    return -1;
  }

  if (mUsedCount >= MAX_SYMBOLS)
  {
    (void)printf("APISymbolTableEnt:Add: table size reached\n");
    return -1;
  }
  
  (mTable[mUsedCount]).Load (labelS, valueS);
  mUsedCount++;
  return mUsedCount;
}


/********************************************************************
  Adds a value pair (label/value) to the table. The value is a long.
  Returns -1 on failure.
********************************************************************/
int
APISymbolTable::Add(const char *labelS, long int valueI)
{
  if (labelS == NULL)
  {
    (void)printf("APISymbolTableEnt:Add: NULL value passed in argument 1\n");
    return -1;
  }

  char buf[50];
  sprintf(buf, "%ld", valueI);
  return Add(labelS, buf);
}


/********************************************************************
  Find a label in the table. Returns the labels value or NULL on
  failure.
********************************************************************/
char *
APISymbolTable::Find(const char *l)
{
  if (l == NULL)
  {
    (void)printf("APISymbolTableEnt:Find: NULL value passed in argument 1\n");
    return NULL;
  }

  for (int i=0; i<mUsedCount; i++)
  {
    if (mTable[i].IsEqual(l)) 
      return mTable[i].valueS;
  }
  return NULL;
}


/********************************************************************
  Print each internal label/value pair of the symbol table.
********************************************************************/
void	
APISymbolTable::PrintAll()
{
  printf("%d labels.\n", mUsedCount);
  for (int i=0; i<mUsedCount; i++)
  {
    if ( (mTable[i].valueS != NULL) && (mTable[i].labelS != NULL) )
      printf ("%s: %s\n", mTable[i].labelS, mTable[i].valueS);
  }
  printf("\n");
}

// local variables:
// mode: c++
// compile-command: "make APISymbolTable.o"
// end:
