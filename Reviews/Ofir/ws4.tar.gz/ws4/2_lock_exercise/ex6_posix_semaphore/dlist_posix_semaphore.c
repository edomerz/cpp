#include <pthread.h> 	/* pthread_mutex_/lock/unlock */
#include <unistd.h>		/* usleep() */
#include <errno.h> 		/* errno, perror() */
#include <semaphore.h>	/* sem_post, sem_wait */
#include "dlist.h"

#define SLEEP_DURATION_READER 100
#define SLEEP_DURATION_WRITER 100

size_t global_counter = 0;


typedef struct args 
{
	pthread_mutex_t *dlist_mutex;
	sem_t *dlist_semaphore;
	dlist_t *dlist;
} args_t;


/*  DListFrontWriter pushes an element to the front of the  dlist and prints 
	the updated size of the list resulted from the writing operation */
void *DListFrontWriter(void *args)
{	
	while (1)
	{	
		/* locking the mutex while checking for a non-error value */
		if (pthread_mutex_lock(((args_t *)args)->dlist_mutex))
		{
			perror("writer pthread_mutex_lock() error");
			exit(1);
		}
		
		/* pushing the element. we use the global_counter as the element's data */
		DListPushFront(((args_t *)args)->dlist, (void *)global_counter);
		
		/* updating the counter */
		++global_counter;
		
		/* varifying the size equals the counting */
		printf("dlist updated size, after writing: %lu (expected: %lu)\n", 
				global_counter, DListSize(((args_t *)args)->dlist));
						
		/* Post to the semaphore: increment its value by 1 */
		sem_post(((args_t *)args)->dlist_semaphore);
		
		/* unlocking the mutex */
		if (pthread_mutex_unlock(((args_t *)args)->dlist_mutex))
		{
			perror("writer pthread_mutex_unlock() error");
			exit(1);
		}
		
		/* a short sleep to be able to see what's printing */
		usleep(SLEEP_DURATION_WRITER);	
	}
	
	/* unused */
	return NULL;	
}

/*  DListFrontReader pops the first element of the list and prints the updated 
	size of the list resulted from the reading operation */
void *DListFrontReader(void *args)
{
	while (1)
	{	
		/* waiting on the semaphore if its value is 0 (= list empty, so there are 
			no nodes to pop). otherwise (= semval > 0), atomically decrements its 
			value by 1 and moves on to the critical section. */
		sem_wait(((args_t *)args)->dlist_semaphore);
		
		/* locking the mutex while checking for a non-error value */
		if (pthread_mutex_lock(((args_t *)args)->dlist_mutex))
		{
			perror("writer pthread_mutex_lock() error");
			exit(1);
		}
		
		/* popping the lis't first element. */
		DListPopFront(((args_t *)args)->dlist);
		
		/* updating the counter */
		--global_counter;
			
		/* varifying the size equals the counting */
		printf("\t\t\tdlist updated size, after reading: %lu (expected: %lu)\n", 
				global_counter, DListSize(((args_t *)args)->dlist));
				
		/* unlocking the mutex */
		if (pthread_mutex_unlock(((args_t *)args)->dlist_mutex))
		{
			perror("writer pthread_mutex_unlock() error");
			exit(1);
		}
		
		/* a short sleep to be able to see what's printing */	
		usleep(SLEEP_DURATION_READER);	
	}
	
	/* unused */
	return NULL;	
}
