/* The _BSD_SOURCE is for compiling usleep with our usual flags, 
	and it has to be above all includes */
#define _BSD_SOURCE
#include <unistd.h>		/* usleep() */
#include <errno.h> 		/* errno, perror() */
#include "circ_buf.h"
#include "consumer_producer.h"

#define SLEEP_DURATION_READER 10000
#define SLEEP_DURATION_WRITER 500

int global_counter = 0;

/*  DListFrontWriter pushes an element to the front of the  dlist and prints 
	the updated size of the list resulted from the writing operation */
void *CircBuffWriter(void *args)
{	
	while (1)
	{	
		/* waiting on the free_space_semaphore if its value is 0 (= freespace is 0,
			meaning there is no more space to write into). otherwise (= semval > 0), 
			atomically decrements its value by 1 (= 1 less freespace to write into)
			and moves on to the critical section. */
		sem_wait(((args_t *)args)->free_space_semaphore);
		
		/* locking the mutex while checking for a non-error value */
		if (pthread_mutex_lock(((args_t *)args)->circbuf_mutex))
		{
			perror("writer pthread_mutex_lock() error");
			exit(1);
		}
		
		/* pushing the element. we use the global_counter as the element's data */
		CircBufWrite(((args_t *)args)->circ_buf, &global_counter);
		
		/* updating the counter */
		++global_counter;
		
		/* varifying the free space equals the capacity-minus-counting */
		printf("circ_buf updated FREE SPACE(!), after writing: %lu (expected: %lu)\n", 
					CircBufFreeSpace(((args_t *)args)->circ_buf), 
					((args_t *)args)->circ_buf->capacity - global_counter);
						
		/* Post to the occupied_space_semaphore: increment its value by 1, meaning:
			there is one more space that is occupied. */
		sem_post(((args_t *)args)->occupied_space_semaphore);
		
		/* unlocking the mutex */
		if (pthread_mutex_unlock(((args_t *)args)->circbuf_mutex))
		{
			perror("writer pthread_mutex_unlock() error");
			exit(1);
		}
		
		/* a short sleep to be able to see what's printing */
		usleep(SLEEP_DURATION_WRITER);	
	}
	
	/* unused */
	return NULL;	
}

/*  DListFrontReader pops the first element of the list and prints the updated 
	size of the list resulted from the reading operation */
void *CircBuffReader(void *args)
{
	while (1)
	{	
		/* waiting on the occupied_space_semaphore if its value is 0 (= no occupied space,
			so there is nothing to read). otherwise (= semval > 0), atomically 
			decrements its value by 1 (= 1 less occupied space to read from) and
			moves on to the critical section. */
		sem_wait(((args_t *)args)->occupied_space_semaphore);
		
		/* locking the mutex while checking for a non-error value */
		if (pthread_mutex_lock(((args_t *)args)->circbuf_mutex))
		{
			perror("writer pthread_mutex_lock() error");
			exit(1);
		}
		
		/* popping the lis't first element. */
		CircBufRead(((args_t *)args)->circ_buf);
		
		/* updating the counter */
		--global_counter;
			
		/* varifying the free space equals the capacity-minus-counting */
		printf("\t\t\tcirc_buf updated FREE SPACE(!), after reading: %lu (expected: %lu)\n", 
					CircBufFreeSpace(((args_t *)args)->circ_buf), 
					((args_t *)args)->circ_buf->capacity - global_counter);
		
		/* Post to the free_space_semaphore: increment its value by 1, meaning:
			there is one more space that had been read and is now free. */
		sem_post(((args_t *)args)->free_space_semaphore);
				
		/* unlocking the mutex */
		if (pthread_mutex_unlock(((args_t *)args)->circbuf_mutex))
		{
			perror("writer pthread_mutex_unlock() error");
			exit(1);
		}
		
		/* a short sleep to be able to see what's printing */	
		usleep(SLEEP_DURATION_READER);	
	}
	
	/* unused */
	return NULL;	
}
