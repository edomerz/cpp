#ifndef __BARRIERS_CONCURRENT_CONS_PROD_H__
#define __BARRIERS_CONCURRENT_CONS_PROD_H__

#define _GNU_SOURCE
#include <pthread.h> /* pthread_mutex_init/lock/unlock */
#include <semaphore.h>

/*
struct circ_buf
{
	size_t capacity;				
	size_t size; 					
	size_t read_index;
	size_t write_index;
	size_t circular_buffer[1];
};
*/
typedef struct args 
{
	circ_buf_t *circ_buf;
	pthread_barrier_t done_writing;
	pthread_barrier_t done_reading;
	size_t capacity;
} args_t;


void *CircBuffWriter(void *args);
void *CircBuffReader(void *args);

#endif /* __BARRIERS_CONCURRENT_CONS_PROD_H__ */
