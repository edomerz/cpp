#include <pthread.h>
#include <stdio.h>
#include <unistd.h>

/* Create a lot of threads, to check if using detach helps for NOT stopping at
	32752 threads limititaion on number */

int global_array[50000] = {0};

/* a simple function that prints 100 x's */
void *PrintX(void *i)
{
	global_array[*(int *)i] = *(int *)i;
	
	return (NULL);
}

int main()
{
	int i;
	
	/* this will hold the thread id */
	pthread_t thread_id;
	
	for (i = 0; i < 50000; ++i)
	{
		pthread_create(&thread_id, NULL, &PrintX, &i);
		pthread_detach(thread_id);
	}
	
	for (i = 0; i < 50000; ++i)
	{
		printf("global_array[%d]: %d\n", i, global_array[i]);
	}
	
	return (0);	
}

