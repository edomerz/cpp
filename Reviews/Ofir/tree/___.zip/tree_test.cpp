#include <iostream>
#include <cstdio>
#include "tree.h"	
		
using namespace ilrd;
		
int main(int argc, char *argv[])
{
	
	printf("Hello User! Enter a directory that shall be the repository.\n");
	printf("--> Note: . and .. are currently not supported.\n");
	printf("Enter repository:\n");
	std::string buffer;
	std::cin >> buffer;
	Component *repo = CreateRepository(buffer);
	
	printf("Repository is ready. Now, enter a sub-repository path you want to\n"
			"format as a tree.\n");
	
	Component *dir = 0;
	while (!dir)
	{
		printf("Enter path:\n");
		std::cin >> buffer; // doesnt work well: cant go back
		dir = FindPath(repo, buffer);
	}
	dir->Display(0);
	

	delete repo;	
}		
				
				
				
