#define _GNU_SOURCE
#include "circ_buf.h"
#include "cond_var_prod_cons.h"

#define WRITER_THREADS 1
#define READER_THREADS 4

int main()
{
	key_t key;
	union semun semun_arg;
	
	int i = 0;
	size_t capacity = 10;
	
	pthread_t writer_threads_id_array[WRITER_THREADS] = {0}; 
	pthread_t reader_threads_id_array[READER_THREADS] = {0}; 
	
	args_t args_instance;
	
	/* initializing the mutex */
	if(pthread_mutex_init(&args_instance.mutex, NULL))
	{
		perror("pthread_mutex_init() error");
		exit(1);
	}
	
	/* initializing the semaphore */
	key = ftok("dlist.c", 'S');	
	args_instance.semid = InitSemaphore(key, 1);
	
	/*
	if()
	{
		perror("pthread_sem_init() error");
		exit(1);
	}
	*/

	/* initializing the condition variable */
	if(pthread_cond_init(&args_instance.operation_done_cv_flag, NULL))
	{
		perror("pthread_cond_init() error");
		exit(1);
	}
	
	/* creating circular buffer */
	args_instance.circ_buf = CircBufCreate(capacity);
	
	args_instance.num_of_readers = READER_THREADS;
	args_instance.capacity = capacity;
	
	/* Testing DListWriter & DListReader, that use mutexes */
	/**********************************************************************/
	
	for (i = 0 ; i < WRITER_THREADS; ++i)
	{
		if (pthread_create(&writer_threads_id_array[i], NULL, CircBuffWriter, &args_instance))
		{
			perror("pthread_create() error");                                           
    		exit(1);
		}
	}
	for (i = 0 ; i < READER_THREADS; ++i)
	{	
		if (pthread_create(&reader_threads_id_array[i], NULL, CircBuffReader, &args_instance))
		{
			perror("pthread_create() error");                                           
    		exit(1);
		}
	}
	
	for (i = 0 ; i < WRITER_THREADS; ++i)
	{
		if (pthread_join(writer_threads_id_array[i], NULL))
		{
			perror("pthread_join() error");                                       
    		exit(2);
		}
	}
	for (i = 0 ; i < WRITER_THREADS; ++i)
	{
		if (pthread_join(reader_threads_id_array[i], NULL))
		{
			perror("pthread_join() error");                                       
    		exit(2);
		}
	}
			

	/* WON'T BE EXECUTED SINCE WE DONT HAVE A NORMAL TERMINATION HERE (WE TERMINATE
		WITH CTRL+C)  */
	/* ***********************************************************************/
	/* destroying the circ_buf. */
	CircBufDestroy(args_instance.circ_buf);
	
	/* destroying the mutexes. */
	if(pthread_mutex_destroy(&args_instance.mutex))
	{
		perror("pthread_mutex_destroy() error");
		exit(1);
	}
	
	/* destroying the semaphore set. */
	semctl(args_instance.semid, 0, IPC_RMID, semun_arg);
	/*
	if();
	{
		perror("sem_destroy() error");
		exit(1);
	}
	*/
	
	/* destroying the condition variable. */
	if(pthread_cond_destroy(&args_instance.operation_done_cv_flag))
	{
		perror("pthread_cond_destroy() error");
		exit(1);
	}

	
	

	return (0);
}

