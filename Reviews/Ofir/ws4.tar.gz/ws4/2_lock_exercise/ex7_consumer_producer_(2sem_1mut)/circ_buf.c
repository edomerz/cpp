
#include "circ_buf.h"

struct circ_buf
{
	size_t capacity;				/* total elements */
	size_t size; 					/* number of written elements */
	size_t read_index;
	size_t write_index;
	size_t circular_buffer[1];
};

/* Creates a circular buffer with "capacity" bytes, and returns a pointer to it */
circ_buf_t *CircBufCreate(size_t capacity)
{
	circ_buf_t *circ_buf = 
	(circ_buf_t *) malloc (sizeof(circ_buf_t) + (capacity * sizeof(int)) - sizeof(size_t));
	
	if (!circ_buf)
	{
		return NULL;
	}
	
	circ_buf->capacity = capacity;
	circ_buf->size = 0;
	circ_buf->write_index = 0;
	circ_buf->read_index = 0;
	
	return (circ_buf);
}

/* Destroys a circular buffer */
void CircBufDestroy(circ_buf_t *circ_buf)
{
	assert(circ_buf);
	
	free(circ_buf);
}

/* Returns the free space (in 'units' of elements) left to write on in the buffer */
size_t CircBufFreeSpace(const circ_buf_t *circ_buf)
{
	assert(circ_buf);
	
	return (circ_buf->capacity - circ_buf->size);
}

/* Returns the total capacity (in bytes) of the buffer */ 
size_t CircBufCapacity(const circ_buf_t *circ_buf)
{
	assert(circ_buf);
	
	return (circ_buf->capacity);
}

/* Reads an int from the circ_buff, without storing them anywhere but simply
	advancing the reading index.  */
void CircBufRead(circ_buf_t *circ_buf)
{	
	assert(circ_buf);
	
	/* incrementing read_index by 1 % capacity */ 
	circ_buf->read_index = (circ_buf->read_index + 1) % circ_buf->capacity;
	
	/* reading is cosuming. Thus, once reading an element, the size is decremented by 1 */
	circ_buf->size -= 1;
}


/* Writes "n_bytes" to the buffer, obtaining them from the location given by src. 
	It returns the number of bytes written. */
void CircBufWrite(circ_buf_t *circ_buf, const int *data)
{	
	assert(circ_buf);
	assert(data);
	
	*((int *)(circ_buf->circular_buffer) + circ_buf->write_index) = *data;
	
	/* incrementing write_index by 1 % capacity */ 
	circ_buf->write_index = (circ_buf->write_index + 1) % circ_buf->capacity;
	
	circ_buf->size += 1;
}


/*
	printf("circbuff address: %p\n", (char *)(circ_buf->circular_buffer));
	printf("number 4: %d\n", *(int *)((char *)circ_buf->circular_buffer));
	
	printf("circbuff address: %p\n", ((char *)(circ_buf->circular_buffer) + 4));
	printf("number 4: %d\n", *(int *)(((char *)(circ_buf->circular_buffer) + 4)));
*/

