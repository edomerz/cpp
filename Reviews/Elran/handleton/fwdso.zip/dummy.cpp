#include "dummy.h"


extern "C" {void DoAdd()
{
using namespace ilrd;
	Handleton<counter> counter_instance2;
	counter_instance2->Inc();
	counter_instance2->PrintCounter();
}}
