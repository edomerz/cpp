#define _BSD_SOURCE 
#include <iostream>
#include <cstdio>
#include <dirent.h>
#include <errno.h>
#include <stdlib.h>
#include <boost/filesystem.hpp>
#include "tree.h"	

#define RESET     "\033[0m"
#define BOLDBLUE  "\033[1m\033[34m"      /* Bold Blue */

namespace ilrd				
{					
	// takes care of the formatting of the last directory WITHIN a directory
	static void LastDirDisplay(int level, std::string dir_name, 
								const std::vector<Component *>& v, int flag);
								
	// takes care of the formatting of the last file WITHIN a directory
	static void LastFileDisplay(int level, std::string dir_name, int flag);
	
	Component::Component(const std::string& name_) : m_name(name_)				
	{}	
	
	std::string Component::GetName() const 			
	{
		return (m_name);
	}
	
	Component::~Component()				
	{}
	
	void Component::Display(int level, int flag) const			
	{}
	
	Directory::Directory(const std::string& name_): Component(name_)
	{}
	
	Directory::~Directory()
	{
		for (int i = 0; i < v.size(); ++i)
		{
			delete v[i];
		}
	}
	
	std::vector<Component *>& Directory::GetVec()
	{
		return (v);
	}
	
	static void DirectoryDisplayAux(int level, std::string dir_path, 
										const std::vector<Component *>& v, int flag)
	{
        boost::filesystem::path temp_dir_path(dir_path);
		std::string dir_name = (--temp_dir_path.end())->string();
		std::cout<<BOLDBLUE<<dir_name<<RESET<<std::endl;
		
		// traverses the directory's components vector and calls Display on 
		// each component.
		for (size_t i = 0; i < v.size(); ++i)
		{
			if (i < (v.size() - 1))
			{
				v[i]->Display(level+1, flag); // not ++level (which changes 'level' itself)
			}
			// for formatting purposes, we treat the last component differently
			else
			{
				boost::filesystem::path temp(v[i]->GetName());
				if (*(temp.begin()) == "/")
				{
					LastDirDisplay(level+1, v[i]->GetName(), 
								static_cast<Directory *>(v[i])->GetVec(), 0);
				}
				else
				{
					LastFileDisplay(level+1, v[i]->GetName(), flag);
				}
			}
		}
	}
	
	// takes care of the formatting of the last directory WITHIN a directory
	static void LastDirDisplay(int level, std::string dir_name, 
								const std::vector<Component *>& v, int flag)
	{
		if (level > 1)
		{
			for(int i = 0; i < level - 1; ++i)
			{
				std::cout<<"│";
				std::cout<<"    ";
			}
		}
		if (level >= 1)
		{
			std::cout << "└── ";
		}

		//prints the name of the Directory
		DirectoryDisplayAux(level, dir_name, v, flag);

	}
	
	void Directory::Display(int level, int flag) const
	{
		if (level > 1 && !flag)
		{
			std::cout<<"│";
			for(int i = 0; i < level - 1; ++i)
			{
				std::cout<<"    ";
			}
		}
		
		if (level > 1 && flag)
		{
			for(int i = 0; i < level - 1; ++i)
			{
				std::cout<<"│";
				std::cout<<"    ";
			}
		}
		if (level >= 1)
		{
			std::cout << "├── ";
		}
		
		
		//prints the name of the Directory
		DirectoryDisplayAux(level, GetName(), v, flag);
	}
	
	void Directory::Add(Component *inst_)
	{
		v.push_back(inst_);
		return;
	}
	
	File::File(const std::string& name_): Component(name_)
	{}
	
	File::~File()
	{}
	
	static void FileDisplayAux(int level, std::string hook_type, std::string file_name, int flag)
	{
		if(flag)
		{
			for(int i = 0; i < level-1; ++i)
			{
				std::cout<<"│";
				std::cout<<"    ";
			}
		}
        else
	    {
			// THIS PART IS STILL NOT WORKING, AND I HAD ENOUGH.
			if (level == 2)
			{
				std::cout<<"    ";
			}
			if (level > 2)
			{
				std::cout<<"│";
				for(int i = 0; i < level-2; ++i)
				{
					std::cout<<"    ";
				}
				std::cout<<"│";
				std::cout<<"   ";
			}	
			
		}
        
		std::cout << hook_type;
		std::cout << file_name << std::endl;
	}
	
	void File::Display(int level, int flag) const
	{
		FileDisplayAux(level, "├── ", GetName(), flag);
	}
	
	static void LastFileDisplay(int level, std::string file_name, int flag)
	{
		FileDisplayAux(level, "└── ", file_name, flag);
	}
	
	/* we return component to allow using links (hard/symbolic) - they are not
		directory, only points to directory*/
	Component* CreateRepository(const std::string& path_)
	{
		Directory *dir = new Directory(path_);
		
		DIR *directory_entry = opendir(path_.c_str());
		
		struct dirent *current_entry = 0;
		
		while((current_entry = readdir(directory_entry)))
		{
			// d_type is not standard, consider using stat()
			if(current_entry->d_type == DT_REG)
			{
				dir->Add(new File(current_entry->d_name));
			}
			
			if(current_entry->d_type == DT_DIR)
			{
				if(strcmp(current_entry->d_name, ".") == 0) continue;
    			if(strcmp(current_entry->d_name, "..") == 0) continue;

				dir->Add(CreateRepository(path_ + "/" + current_entry->d_name));
			}	 
		}
		
		closedir (directory_entry);
		
		return dir;
	}
					
	Component* FindPath(Component* repo_, const std::string& path_)
	{
		std::string repo_name = repo_->GetName();
		
		if(path_.compare(0, repo_name.size(), repo_name))
		{
			std::cout << "this path is not in the repository. please enter a valid path\n";
			return (NULL);
		}
		
		boost::filesystem::path repo_path(repo_name);
		boost::filesystem::path path2display(path_);
		
		/* creating an iterator to the path entered by the user, and then advancing 
			the iterator to the directory name of the path2display.
			e.g., if the repo_path is: "/usr/local/games", 
			and the path enterd by the user is "/usr/local/games/bumpy/plugins"
			the iterator will point to the string "games" inside the user's path.
			the "minus 1" is needed because .end() points to an empty space.
			Note: Advancing the iterator with operator + or += doesn't work. */
		boost::filesystem::path::iterator iter_p2d = path2display.begin();
		std::advance(iter_p2d, (std::distance(repo_path.begin(), repo_path.end()) - 1));
		
		Directory *dir = static_cast<Directory *>(repo_);
		 
		for(; iter_p2d != path2display.end(); ++iter_p2d)
		{
			std::cout << "outer loop: "<<iter_p2d->string() << std::endl;
			
			for (int i = 0; i < dir->v.size(); ++i)
			{
				boost::filesystem::path temp(dir->v[i]->GetName());
				
				if ((--temp.end())->string() == iter_p2d->string())
				{
					dir = static_cast<Directory *>(dir->v[i]);

				}
			}
		}
		
		return(dir);
	}
		
}				
				
				
