#ifndef __BARRIERS_CONCURRENT_CONS_PROD_H__
#define __BARRIERS_CONCURRENT_CONS_PROD_H__

#define _GNU_SOURCE
#include <pthread.h> /* pthread_mutex_init/lock/unlock */
#include <semaphore.h>
#include <sys/types.h>	/* ftok, key_t */
#include <sys/ipc.h> 	/* ftok (though somehow it works without this include) */
#include <sys/sem.h> 	/* semctl */

typedef struct args 
{
	circ_buf_t *circ_buf;
	pthread_cond_t operation_done_cv_flag;
	pthread_mutex_t mutex;
	size_t num_of_readers;
	int semid;
	size_t capacity;
} args_t;

union semun 
{
    int val;
    struct semid_ds *buf;
    ushort *array;
};

int InitSemaphore(key_t key, int num_of_semaphores); 
void *CircBuffWriter(void *args);
void *CircBuffReader(void *args);

#endif /* __BARRIERS_CONCURRENT_CONS_PROD_H__ */
