/****************************************
*
*	pre_handleton Project Test file	pre_handleton_test.cpp
*	05-04-2016
*	
*	Production : Elran Sarusi
*	Reviewed by :
*
****************************************/


#include	"pre_handleton.h"
#include	"counter_handleton.h"
#include	"handleton.h"
#include	"dummy.h"



using namespace ilrd;
/*****************MAIN******************/
int main (int argc, char *argv[], char **envp)
{

	Handleton<counter> counter_instance;
	counter_instance->Inc();
	counter_instance->PrintCounter();

	DoAdd();









	

	return (0);	
	
}
/****************MAIN END***************/
