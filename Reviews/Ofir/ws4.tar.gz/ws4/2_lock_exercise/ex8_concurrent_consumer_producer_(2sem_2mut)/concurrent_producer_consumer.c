#define _BSD_SOURCE		/* The _BSD_SOURCE is for compiling usleep with our usual flags, 
							and it has to be above all includes */
#include <unistd.h>		/* usleep() */
#include <errno.h> 		/* errno, perror() */
#include "circ_buf.h"
#include "concurrent_consumer_producer.h"

#define SLEEP_DURATION_READER 0
#define SLEEP_DURATION_WRITER 0

int global_counter = 0;

/*  Writes an element into the next available-to-write index inside the circ_buf */
void *CircBuffWriter(void *args)
{	
	while (1)
	{	
		/* waiting on the free_space_semaphore if its value is 0 (= freespace is 0,
			meaning there is no more space to write into). otherwise (= semval > 0), 
			atomically decrements its value by 1 (= 1 less freespace to write into)
			and moves on to the critical section. */
		sem_wait(&((args_t *)args)->free_space_semaphore);
		
		/* locking the mutex while checking for a non-error value */
		if (pthread_mutex_lock(&((args_t *)args)->writer_mutex))
		{
			perror("writer pthread_mutex_lock() error");
			exit(1);
		}
		
		printf("started writing\n");
		
		/* pushing the element. we use the global_counter as the element's data */
		CircBufWrite(((args_t *)args)->circ_buf, &global_counter);
		
		/* updating the counter */
		++global_counter;

		printf("I've just written the value: %d\n", global_counter); 
						
		/* Post to the occupied_space_semaphore: increment its value by 1, meaning:
			there is one more space that is occupied. */
		sem_post(&((args_t *)args)->occupied_space_semaphore);
		
		printf("finished writing\n\n");
		
		/* unlocking the mutex */
		if (pthread_mutex_unlock(&((args_t *)args)->writer_mutex))
		{
			perror("writer pthread_mutex_unlock() error");
			exit(1);
		}
		

		/* a short sleep to be able to see what's printing */
		usleep(SLEEP_DURATION_WRITER);	
	}
	
	/* unused */
	return NULL;	
}

/*  Reads the next available-to-read element from the circ_buf */
void *CircBuffReader(void *args)
{
	int returned;
	
	while (1)
	{	
		/* waiting on the occupied_space_semaphore if its value is 0 (= no occupied space,
			so there is nothing to read). otherwise (= semval > 0), atomically 
			decrements its value by 1 (= 1 less occupied space to read from) and
			moves on to the critical section. */
		sem_wait(&((args_t *)args)->occupied_space_semaphore);
		
		/* locking the mutex while checking for a non-error value */
		if (pthread_mutex_lock(&((args_t *)args)->reader_mutex))
		{
			perror("writer pthread_mutex_lock() error");
			exit(1);
		}
		
		printf("\t\t\tstarted reading\n");
		
		/* reading the lis't first element. */
		returned = CircBufRead(((args_t *)args)->circ_buf);
			
		/* in this exercise, checking the free space is meaningless. why? here's
		a scenario: lets say we are at the beggining, when the circ_buf is empty: 
		1. the writer is inside ITS mutex. it had performed a writing, and is now
			one moment before printing the current free space - but now the CPU
			decides to put the writer aside and allows a reader a CPU time.
		2. The reader comes and read the written element, performing a read operation, 
			and is now one moment before printing the current free space - but now 
			the CPU decides to put the reader aside and gives back the CPU time to
			the writer.
		3. the writer now prints the free_space, and it would be...zero: while
			the writer was sleeping, dreaming about its read operation, the reader
			came and read it, so that when the writer woke up - the Write 
			resolved as nothing but a dream. :)
		4. look inside the text file inside this directory to understand what happend.
		5. therefore, we'll change the prototype of CirqBufRead, so that it returns
			an int, and this int is the global_counter value that was entered 
			by Writer.
			Note that once applying this change, Reader won't change the global_counter. */
		/*
		printf("\t\t\tcirc_buf updated FREE SPACE(!), after reading: %lu (expected: %lu)", 
					CircBufFreeSpace(((args_t *)args)->circ_buf), 
					((args_t *)args)->circ_buf->capacity - global_counter);
		*/
		
		printf("\t\t\tI've just read the value: %d\n", returned); 
					
		/* Post to the free_space_semaphore: increment its value by 1, meaning:
			there is one more space that had been read and is now free. */
		sem_post(&((args_t *)args)->free_space_semaphore);
			
		printf("\t\t\tfinished reading\n\n");	
				
		/* unlocking the mutex */
		if (pthread_mutex_unlock(&((args_t *)args)->reader_mutex))
		{
			perror("writer pthread_mutex_unlock() error");
			exit(1);
		}
	
		/* a short sleep to be able to see what's printing */	
		usleep(SLEEP_DURATION_READER);	
	}
	
	/* unused */
	return NULL;	
}
