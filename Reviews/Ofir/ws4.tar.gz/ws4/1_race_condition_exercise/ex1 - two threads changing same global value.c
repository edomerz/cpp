#include <pthread.h>
#include <stdio.h>
#include <unistd.h>


int glob = 0;

/* a simple function that prints 100 x's */
void *PrintX(void *unused)
{
	int local;
/*	static int stat;*/
	
	for (local = 0; local > -50; --local)
	{
		printf(" local: %d\n", local);
		printf("static: %d\n", *(int *)unused);
		printf("global: %d\n", glob);
		printf("addres: %lu\n", (size_t)&unused);
		--*(int *)unused;
		--glob;
		printf("\n");
	}
	
	return (NULL);
}


int main()
{
	int local;
	static int stat;
	
	/* this will hold the thread id */
	pthread_t thread_id;
	
	/* creating the new thread */
	/* thread_id will hold the id, */
	pthread_create(&thread_id, NULL, &PrintX, &stat);
	
	/* the main function will continue to print o's 100 times */
	pthread_join(thread_id, NULL);

	for (local = 0; local < 50; ++local)
	{
		printf("\t local: %d\n", local);	
		printf("\tstatic: %d\n", stat);
		printf("\tglobal: %d\n", glob);
		printf("\taddres: %lu\n", (size_t)&stat);
		++stat;
		++glob;
		printf("\n");
		
	}

	sleep(1);
	
	return (0);	
}
