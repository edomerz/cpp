
#ifndef __COMMON_H__
#define __COMMON_H__

#include "resource.h"

BOOL CRI_Success(HRESULT hr);

#endif
