#define _BSD_SOURCE
#define _GNU_SOURCE		
#include <unistd.h>		/* usleep() */
#include <errno.h> 		/* errno, perror() */
#include "circ_buf.h"
#include "cond_var_prod_cons.h"

#define SLEEP_DURATION_READER 500
#define SLEEP_DURATION_WRITER 500


static int SemaphoreWait(int semid, size_t num_of_readers);
static int SemaphorePost(int semid);

int global_counter = 0;

/* Initialize a mutex & a semaphore with a value of 0 (meaning: the dlist has 0 nodes). */
/* key from ftok(), num_of_semaphores with value '1' means one semaphore */
int InitSemaphore(key_t key, int num_of_semaphores)  
{
    /* mendatory declaration of union semun (semaphore_union), to be used for 
    	assiging its .val member with the desired initial value of the semaphore */
    union semun semun_instance;
     
    /* IPC_EXCL: When used with IPC_CREAT, fail if semaphore set already exists. */
    /* 666 are rw-rw-rw- permissions (for the user to r&w the semaphores set) */
    int semid = semget(key, num_of_semaphores, IPC_CREAT | IPC_EXCL | 0666);
    
	/* if semid >=0, the semget returned a non-zero semid value, and it means that a new 
		semaphores set was created */
    /* if the semaphore's id that complies with the passed key is already exists,
    	and semflg specified both IPC_CREAT and IPC_EXCL, semget returns an error, 
    	namely: it updates errno with EEXIST value */ 
    if (errno == EEXIST) 
    { 
		/* get the id */
        semid = semget(key, num_of_semaphores, 0);
         
        /* if semid is negative, that's an error, check errno */
        if (semid < 0) 
        {
        	perror("semid error");
			exit(1);
        }   	  	
	}
	
	/* used for SETVAL only */
    semun_instance.val = 0;
    
	/* SETVAL means: Set the value of the specified semaphore to the value 
		in the val member of the passed-in union semun. */
	semctl(semid, 0, SETVAL, semun_instance);
	
	/* to get the semaphore value */
    /* printf("semval: %d\n", ); */
    
    return semid;
}

/* Writes an element into the next available-to-write index inside the circ_buf */
void *CircBuffWriter(void *args)
{	
	size_t i = 0;
	
	while (1)
	{	
		/* wait untill semaphore's value is equal to the number of readers.
			internally, SemaphoreWait - using semop function - will asign the 
			semaphore with num_of_readers as a NEGATIVE value, and this action 
			will decrement the initial value of the semaphore (that was: num_of_readers) 
			to 0, and also blocks the calling process (=the writer) until the 
			value of the semaphore is greater than or equal to the absolute value 
			of sem_op (= num_of_readers) - and this will happen once each one of
			the readres has sent a post signal. (actually, semop first block and then 
			add (effectively subtract, since it's negative) the value of sem_op to
			the semaphore's value. */
		SemaphoreWait(((args_t *)args)->semid, ((args_t *)args)->num_of_readers);
		
		/* lock on critical section of writing */
		pthread_mutex_lock(&((args_t *)args)->mutex);
		
		/* CRITICAL SECTION: WRITING */
		printf("started writing\n");
		
		for (i = 0; i < ((args_t *)args)->capacity; ++i)
		{
			/* writing the element. we use the global_counter as the element's data */
			CircBufWrite(((args_t *)args)->circ_buf, &global_counter);
			
			if (!(i % 2))
			{
				printf("written: %d, into circbuf[%lu]\n", global_counter, i); 
			}
		}

		/* updating the counter */
		++global_counter;
		
		printf("finished writing\n\n");
		
		/* a short sleep to be able to see what's printing */
		usleep(SLEEP_DURATION_WRITER);
		
		/* broadcasting to the readers: you can now do your reading operation */
		pthread_cond_broadcast(&((args_t *)args)->operation_done_cv_flag);
		
		/* END OF CRITICAL SECTION */
		
		/* unlocking the critical section */
		pthread_mutex_unlock(&((args_t *)args)->mutex);
	}
	
	/* unused */
	return NULL;	
}

/* Reads the next available-to-read element from the circ_buf */
void *CircBuffReader(void *args)
{
	size_t i = 0;
	int returned;

	while (1)
	{	
		/* Lock the mutex before accessing the critical section (especially the
			conditional variable). */
		/* NOTE: this lock has to be here, and can't be, say, after the Post,
			because in such case, it is possible that all of the readers do
			a post, and a moment after the last reader did a post - the CPU time
			is handed over to the writer - which can now be awaken. however,
			the last reader wasn't put to sleep! so it is possible for this reader
			to get CPU time (recall that the fact that the writer is on a mutex
			doesn't mean nobody can get a CPU time, but that no one can access
			the memory bus/the variables between the lock & unlock), and its next
			instruction will be the lock, and since the writer is also on a lock -
			a deadlock will be caused */  
		pthread_mutex_lock(&((args_t *)args)->mutex);
		
		/* CRITICAL SECTION */
		
		/* Each reader is posting once, to allow the writer start writing once 
			the posting resulted in a number that equals the total num of readers */
		SemaphorePost(((args_t *)args)->semid);

		/* Waiting till writer finish writing and sends a broadcast */
		pthread_cond_wait(&((args_t *)args)->operation_done_cv_flag, 
						  &((args_t *)args)->mutex);

		/* READING */

		printf("\t\t\tstarted reading (my pthread_id: %lu)\n", 
					(size_t)pthread_self());
		
		for (i = 0; i < ((args_t *)args)->capacity; ++i)
		{
			returned = CircBufRead(((args_t *)args)->circ_buf);
		
			if (!(i % 2))
			{
				printf("\t\t\tread: %d, from circbuf[%lu]\n", returned, i); 
			}
		}		
					
		printf("\t\t\tfinished reading (my pthread_id: %lu)\n\n", 
				(size_t)pthread_self());	
	
		/* a short sleep to be able to see what's printing */	
		usleep(SLEEP_DURATION_READER);	
		
		/* END OF CRITICAL SECTION */
		
		/* Lock the mutex before accessing the flag value. */
		pthread_mutex_unlock(&((args_t *)args)->mutex);
	}
	
	/* unused */
	return NULL;	
}

/* Wait on a semaphore (will be used only by Writer function).
	Block the calling process until the value of the semaphore is greater 
	than or equal to the absolute value of sem_op (that will be assigned with
	num_of_readers as a NEGATIVE value) */
static int SemaphoreWait(int semid, size_t num_of_readers)
{
	struct sembuf operations;
	
	/* Use the first (and only) semaphore. */
	operations.sem_num = 0;
	
	/* Decrement by 1. */
	/* if the semaphore's value is non-1, Reader will wait */
	operations.sem_op = -(num_of_readers);
	
	/* Permit undo'ing. */
	operations.sem_flg = SEM_UNDO;
	
	/* this is the actual setting of the semaphore's value. */
	/* NOTE: you can use semctl(semid, 0, GETVAL) to see the semaphore's value */
	return semop(semid, &operations, 1);
}

/* Post to a semaphore (will be used only by Reader function). */
static int SemaphorePost(int semid)
{
	struct sembuf operations;
	
	/* Use the first (and only) semaphore. */
	operations.sem_num = 0;
	
    /* The value of sem_op is added to the semaphore's value. */
	operations.sem_op = 1;
	
	/* Permit undo'ing. */
	operations.sem_flg = SEM_UNDO;
	
	return semop(semid, &operations, 1);
}
