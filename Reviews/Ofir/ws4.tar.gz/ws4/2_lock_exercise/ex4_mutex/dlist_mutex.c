#include <assert.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include "dlist.h"

/* for compiling usleep with our usual flags */
/* #define _BSD_SOURCE */ 

size_t global_counter = 0;
#define SLEEP_DURATION 500

pthread_mutex_t dlist_mutex = PTHREAD_MUTEX_INITIALIZER;

/*  this won't work - you cant call a function globally... : 
	pthread_mutex_init(&dlist_mutex, NULL); */

/*  DListFrontWriter pushes an element to the front of the  dlist and prints 
	the updated size of the list resulted from the writing operation */
void *DListFrontWriter(void *dlist)
{
	while (1)
	{
		/* locking the mutex while checking for a non-error value */
		if (pthread_mutex_lock(&dlist_mutex))
		{
			perror("writer pthread_mutex_lock() error");
			exit(1);
		}
		
		/* pushing the element. we use the global_counter as the element's data */
		DListPushFront((dlist_t *)dlist, (void *)global_counter);
		
		/* updating the counter */
		++global_counter;
		
		/* varifying the size equals the counting */
		printf("dlist updated size, after writing: %lu (expected: %lu)\n", 
				global_counter, DListSize((dlist_t *)dlist));
		
		/* a short sleep to be able to see what's printing */
		usleep(SLEEP_DURATION);
		
		/* unlocking the mutex */
		if (pthread_mutex_unlock(&dlist_mutex))
		{
			perror("writer pthread_mutex_unlock() error");
			exit(1);
		}
	}
	
	/* unused */
	return NULL;	
}

/*  DListFrontReader pops the first element of the list and prints the updated 
	size of the list resulted from the reading operation */
void *DListFrontReader(void *dlist)
{
	while (1)
	{
		/* locking the mutex */
		if (pthread_mutex_lock(&dlist_mutex))
		{
			perror("reader pthread_mutex_lock() error");
			exit(1);
		}
		
		/* if the list is NOT empty, we may 'read'. */
		if (!DListIsEmpty((dlist_t *)dlist))
		{
			/* popping the lis't first element. */
			DListPopFront((dlist_t *)dlist);
			
			/* updating the counter */
			--global_counter;
			
			/* varifying the size equals the counting */
			printf("\t\t\tdlist updated size, after reading: %lu (expected: %lu)\n", 
				global_counter, DListSize((dlist_t *)dlist));
				
			/* a short sleep to be able to see what's printing */	
			usleep(SLEEP_DURATION);
		}
		
		/* unlocking the mutex */
		if (pthread_mutex_unlock(&dlist_mutex))
		{
			perror("reader pthread_mutex_unlock() error");
			exit(1);
		}
	}
	
	/* unused */
	return NULL;	
}
