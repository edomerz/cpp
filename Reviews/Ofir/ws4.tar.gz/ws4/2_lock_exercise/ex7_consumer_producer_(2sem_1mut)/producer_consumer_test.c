#include "circ_buf.h"
#include "consumer_producer.h"

int main()
{
	size_t capacity = 4;
	
	pthread_t writer_thread_id;
	pthread_t reader1_thread_id;
	pthread_t reader2_thread_id;
	
	args_t args_instance;
	
	pthread_mutex_t circbuf_mutex;
	sem_t free_space_sem;
	sem_t occupied_space_sem;
	
	if(pthread_mutex_init(&circbuf_mutex, NULL))
	{
		perror("pthread_mutex_init() error");
		exit(1);
	}
	args_instance.circbuf_mutex = &circbuf_mutex;
	
	if(sem_init(&free_space_sem, 0, capacity))
	{
		perror("sem_init() error");
		exit(1);
	}
	args_instance.free_space_semaphore = &free_space_sem;
	
	if(sem_init(&occupied_space_sem, 0, 0))
	{
		perror("sem_init() error");
		exit(1);
	}
	args_instance.occupied_space_semaphore = &occupied_space_sem;
	
	/* creating circular buffer */
	args_instance.circ_buf = CircBufCreate(capacity);
	

	/* Testing DListWriter & DListReader, that use mutexes */
	/**********************************************************************/
	
	if (pthread_create(&writer_thread_id, NULL, CircBuffWriter, &args_instance))
	{
		perror("pthread_create() error");                                           
    	exit(1);
	}
	/* MULTI-READERS THREADS */
	if (pthread_create(&reader1_thread_id, NULL, CircBuffReader, &args_instance))
	{
		perror("pthread_create() error");                                           
    	exit(1);
	}
	if (pthread_create(&reader2_thread_id, NULL, CircBuffReader, &args_instance))
	{
		perror("pthread_create() error");                                           
    	exit(1);
	}
	
	if (pthread_join(writer_thread_id, NULL))
	{
		perror("pthread_join() error");                                       
    	exit(2); 
	}
	if(pthread_join(reader1_thread_id, NULL))
	{
		perror("pthread_join() error");                                       
    	exit(2); 
	}
	if(pthread_join(reader2_thread_id, NULL))
	{
		perror("pthread_join() error");                                       
    	exit(2); 
	}
	
	
	/* WON'T BE EXECUTED SINCE WE DONT HAVE A NORMAL TERMINATION HERE (WE TERMINATE
		WITH CTRL+C)  */
	/* ***********************************************************************/
	/* destroying the two lists. */
	CircBufDestroy(args_instance.circ_buf);
	
	/* destroying the semaphores. */
	if(sem_destroy(&free_space_sem));
	{
		perror("sem_destroy() error");
		exit(1);
	}
	
	if(sem_destroy(&occupied_space_sem));
	{
		perror("sem_destroy() error");
		exit(1);
	}
	
	/* destroying the mutex. */
	if(pthread_mutex_destroy(&circbuf_mutex))
	{
		perror("pthread_mutex_destroy() error");
		exit(1);
	}
	
	
	return (0);
}



