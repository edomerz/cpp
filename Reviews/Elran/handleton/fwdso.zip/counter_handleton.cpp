/********************************************
*
*	counter_handleton Project definition file:	counter_handleton.cpp
*	05-04-2016
*	
*	Production : Elran Sarusi
*	Reviewed by :
*
*********************************************/

#include"counter_handleton.h"
#define __INSTANCE_EN__
#include"handleton.h"

using namespace ilrd;

extern "C"{ void counter::Inc()
{
	 m_counter++;
}}

extern "C"{ void counter::Dec()
{
	 m_counter--;
}}

extern "C"{ void counter::PrintCounter()
{
	std::cout<<"instance number is ::: "<< m_counter<<"\n"<<std::endl;
}}



//explicit instantiation trick
template
counter*& Handleton<counter>::GetInstance();







  





